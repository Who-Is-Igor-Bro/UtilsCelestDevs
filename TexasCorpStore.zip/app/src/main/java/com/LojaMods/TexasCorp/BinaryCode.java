package Store.System.Utils;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;

public class BinaryCode extends Activity {
     
      @Override
     protected void onCreate(Bundle savedInstanceState) {
              super.onCreate(savedInstanceState);
       }
public void _BinaryForText (final String _TextBinary) {
		String biner = _TextBinary;
		String hasil = ""; char nextChar;
		
		for(int i = 0; i <= biner.length()-8; i += 9) {  nextChar = (char)Integer.parseInt(biner.substring(i, i+8), 2);  hasil += nextChar; }
	}
	
	
	public void _TextForBinary (final String _Text) {
		String text = _Text;
		byte[] bytes = text.getBytes();
		StringBuilder binary = new StringBuilder();
		
		for (byte b : bytes) {
			   int val = b;
			  for (int i = 0; i < 8; i++) { 
				      binary.append((val & 128) == 0
				? 0 : 1);
				  val <<= 1;  }
			    binary.append(' ');
		}
	}
    
    }
     
