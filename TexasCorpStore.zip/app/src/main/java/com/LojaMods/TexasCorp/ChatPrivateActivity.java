package com.LojaMods.TexasCorp;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.media.MediaPlayer;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.File;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class ChatPrivateActivity extends AppCompatActivity {
	
	public final int REQ_CD_IMGPHOTOS = 101;
	public final int REQ_CD_IMGMUSIC = 102;
	public final int REQ_CD_IMGFILES = 103;
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private String OneUserName = "";
	private String SecondUser = "";
	private String Chat1 = "";
	private String Chat2 = "";
	private String pushKey = "";
	private HashMap<String, Object> MapChatPrivate = new HashMap<>();
	private String UserNameVerific = "";
	private String nameOneUser = "";
	private String nameTwoUser = "";
	private String Nome = "";
	private String sender = "";
	private String reciever = "";
	private String PhotoUserOne = "";
	private String FilesN = "";
	private String FilesC = "";
	private double ProgressDonwload = 0;
	private double Largura = 0;
	private double ClickCount = 0;
	private String MusicName = "";
	private boolean PlayMusic = false;
	private double SetCaracterChatPrivate = 0;
	private boolean PlayMusic2 = false;
	private String PhotoN = "";
	private String setCheckedPreview = "";
	private String legendPhoto = "";
	private boolean BooleanChecked = false;
	private String binaryCode = "";
	
	private ArrayList<HashMap<String, Object>> ListMapPrivateChat = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> msgChatPrivate = new ArrayList<>();
	private ArrayList<String> ChatPrivateListStrings = new ArrayList<>();
	
	private LinearLayout linear_Profile;
	private LinearLayout linear5;
	private LinearLayout linear_BackGround;
	private CircleImageView circleimageview1;
	private TextView textview_username;
	private LinearLayout linear7;
	private TextView textview_verifc;
	private LinearLayout linear8;
	private LinearLayout linear_baseMsg;
	private ListView listview1;
	private EditText edittext_msg;
	private ImageView imageview2;
	private ImageView imageview1;
	
	private DatabaseReference chat = _firebase.getReference("chat");
	private ChildEventListener _chat_child_listener;
	private DatabaseReference chat2 = _firebase.getReference("chat2");
	private ChildEventListener _chat2_child_listener;
	private DatabaseReference FbPrivateChat = _firebase.getReference("Stand");
	private ChildEventListener _FbPrivateChat_child_listener;
	private FirebaseAuth user;
	private OnCompleteListener<AuthResult> _user_create_user_listener;
	private OnCompleteListener<AuthResult> _user_sign_in_listener;
	private OnCompleteListener<Void> _user_reset_password_listener;
	private OnCompleteListener<Void> user_updateEmailListener;
	private OnCompleteListener<Void> user_updatePasswordListener;
	private OnCompleteListener<Void> user_emailVerificationSentListener;
	private OnCompleteListener<Void> user_deleteUserListener;
	private OnCompleteListener<Void> user_updateProfileListener;
	private OnCompleteListener<AuthResult> user_phoneAuthListener;
	private OnCompleteListener<AuthResult> user_googleSignInListener;
	
	private SharedPreferences ChatSp;
	private DatabaseReference fbUserInbox = _firebase.getReference("UserInbox");
	private ChildEventListener _fbUserInbox_child_listener;
	private Intent dadosP = new Intent();
	private DatabaseReference FbUserP = _firebase.getReference("Privacy");
	private ChildEventListener _FbUserP_child_listener;
	private AlertDialog.Builder DgPrivacy;
	private StorageReference FilesChatPrivate = _firebase_storage.getReference("PrivateChatFiles");
	private OnCompleteListener<Uri> _FilesChatPrivate_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _FilesChatPrivate_download_success_listener;
	private OnSuccessListener _FilesChatPrivate_delete_success_listener;
	private OnProgressListener _FilesChatPrivate_upload_progress_listener;
	private OnProgressListener _FilesChatPrivate_download_progress_listener;
	private OnFailureListener _FilesChatPrivate_failure_listener;
	
	private AlertDialog.Builder DgFilesSelect;
	private Intent ImgPhotos = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent ImgMusic = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent ImgFiles = new Intent(Intent.ACTION_GET_CONTENT);
	private MediaPlayer MediaPlayerStore;
	private TimerTask LoadSekebar;
	private AlertDialog.Builder SendPhotos;
	private Intent txP = new Intent();
	private Notification NotificationFiles;
	private AlertDialog.Builder DialogCode;
	private Calendar Date = Calendar.getInstance();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.chat_private);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear_Profile = findViewById(R.id.linear_Profile);
		linear5 = findViewById(R.id.linear5);
		linear_BackGround = findViewById(R.id.linear_BackGround);
		circleimageview1 = findViewById(R.id.circleimageview1);
		textview_username = findViewById(R.id.textview_username);
		linear7 = findViewById(R.id.linear7);
		textview_verifc = findViewById(R.id.textview_verifc);
		linear8 = findViewById(R.id.linear8);
		linear_baseMsg = findViewById(R.id.linear_baseMsg);
		listview1 = findViewById(R.id.listview1);
		edittext_msg = findViewById(R.id.edittext_msg);
		imageview2 = findViewById(R.id.imageview2);
		imageview1 = findViewById(R.id.imageview1);
		user = FirebaseAuth.getInstance();
		ChatSp = getSharedPreferences("ChatSp", Activity.MODE_PRIVATE);
		DgPrivacy = new AlertDialog.Builder(this);
		DgFilesSelect = new AlertDialog.Builder(this);
		ImgPhotos.setType("image/*");
		ImgPhotos.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		ImgMusic.setType("audio/*");
		ImgMusic.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		ImgFiles.setType("*/*");
		ImgFiles.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		SendPhotos = new AlertDialog.Builder(this);
		DialogCode = new AlertDialog.Builder(this);
		
		linear_Profile.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				DialogCode.setTitle("Código de Segurança da conversa");
				DialogCode.setMessage("Message");
				DialogCode.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				DialogCode.setNegativeButton("Fechar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				DialogCode.create().show();
			}
		});
		
		listview1.setOnScrollListener(new AbsListView.OnScrollListener() {
			@Override
			public void onScrollStateChanged(AbsListView abs, int _scrollState) {
				
			}
			
			@Override
			public void onScroll(AbsListView abs, int _firstVisibleItem, int _visibleItemCount, int _totalItemCount) {
				
			}
		});
		
		edittext_msg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		edittext_msg.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				SetCaracterChatPrivate = _charSeq.length();
				if (_charSeq.equals("")) {
					imageview2.setVisibility(View.VISIBLE);
				}
				else {
					imageview2.setVisibility(View.GONE);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final com.google.android.material.bottomsheet.BottomSheetDialog DgFilesSelect = new
				com.google.android.material.bottomsheet.BottomSheetDialog(ChatPrivateActivity.this);
				View lay = getLayoutInflater().inflate(R.layout.buttomshet_send_files_layout, null); DgFilesSelect.setContentView(lay);
				
				final ImageView Files = lay.findViewById(R.id.imageview_files);
				final ImageView Music = lay.findViewById(R.id.imageview_music);
				final ImageView Photo = lay.findViewById(R.id.imageview_photos);
				DgFilesSelect.show();
				Files.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						startActivityForResult(ImgFiles, REQ_CD_IMGFILES);
						DgFilesSelect.dismiss();
					}
				});
				Music.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						startActivityForResult(ImgMusic, REQ_CD_IMGMUSIC);
						DgFilesSelect.dismiss();
					}
				});
				Photo.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						startActivityForResult(ImgPhotos, REQ_CD_IMGPHOTOS);
						DgFilesSelect.dismiss();
					}
				});
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (TextUtils.isEmpty(edittext_msg.getText().toString())) {
					
				}
				else {
					MapChatPrivate = new HashMap<>();
					MapChatPrivate.put("PrivateMsg", edittext_msg.getText().toString());
					MapChatPrivate.put("UidMsg", FirebaseAuth.getInstance().getCurrentUser().getUid());
					MapChatPrivate.put("aqv", "NoFile");
					MapChatPrivate.put("remetente", FirebaseAuth.getInstance().getCurrentUser().getUid());
					MapChatPrivate.put("enviado", UserNameVerific);
					MapChatPrivate.put("recebendo", textview_username.getText().toString());
					MapChatPrivate.put("lkPhoto", PhotoUserOne);
					MapChatPrivate.put("Enviando", getIntent().getStringExtra("secondUser"));
					chat.push().updateChildren(MapChatPrivate);
					chat2.push().updateChildren(MapChatPrivate);
					fbUserInbox.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(MapChatPrivate);
					edittext_msg.setText("");
				}
			}
		});
		
		_chat_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				chat.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						ListMapPrivateChat = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								ListMapPrivateChat.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listview1.setAdapter(new Listview1Adapter(ListMapPrivateChat));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				chat.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						ListMapPrivateChat = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								ListMapPrivateChat.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listview1.setAdapter(new Listview1Adapter(ListMapPrivateChat));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		chat.addChildEventListener(_chat_child_listener);
		
		_chat2_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		chat2.addChildEventListener(_chat2_child_listener);
		
		_FbPrivateChat_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("name_stand")) {
						OneUserName = _childValue.get("name_stand").toString();
					}
					PhotoUserOne = _childValue.get("photo_lk").toString();
				}
				if (_childKey.equals(getIntent().getStringExtra("secondUser"))) {
					if (_childValue.containsKey("name_stand")) {
						SecondUser = _childValue.get("name_stand").toString();
						textview_username.setText(SecondUser);
					}
					if (_childValue.containsKey("photo_lk")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("photo_lk").toString())).into(circleimageview1);
					}
					textview_verifc.setText(_childValue.get("verifc").toString());
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		FbPrivateChat.addChildEventListener(_FbPrivateChat_child_listener);
		
		_fbUserInbox_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fbUserInbox.addChildEventListener(_fbUserInbox_child_listener);
		
		_FbUserP_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (getIntent().getStringExtra("secondUser").equals(_childKey) && _childValue.get("Priv").toString().equals("true")) {
					DgPrivacy.setTitle("Esse Usuário não permiti o envio de mensagens!");
					DgPrivacy.setMessage("As mensagens foram desativadas, Não pode enviar mensagens para esse usuário.");
					DgPrivacy.setPositiveButton("ok", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							finish();
						}
					});
					DgPrivacy.setCancelable(false);
					DgPrivacy.create().show();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		FbUserP.addChildEventListener(_FbUserP_child_listener);
		
		_FilesChatPrivate_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				_Notification_Files_forTitle("Upload de Arquivos", "Upload ".concat(String.valueOf((long)(_progressValue))).concat("%"));
				if (_progressValue == 100) {
					_Notification_Files_forTitle("Upload de Arquivos", "Enviado com sucesso!");
				}
			}
		};
		
		_FilesChatPrivate_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				ProgressDonwload = 0;
				_Notification_Files_forTitle("Donwload de Arquivos ", "Donwload ".concat(String.valueOf((long)(_progressValue))).concat("%"));
				if (_progressValue == 100) {
					_Notification_Files_forTitle("Donwload de Arquivos", "Arquivo baixado com sucesso!");
				}
			}
		};
		
		_FilesChatPrivate_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				if (PhotoN.equals("")) {
					if (MusicName.equals("")) {
						MapChatPrivate = new HashMap<>();
						MapChatPrivate.put("PrivateFile", _downloadUrl);
						MapChatPrivate.put("aqv", "File");
						MapChatPrivate.put("aqvN", FilesN);
						MapChatPrivate.put("UidMsg", FirebaseAuth.getInstance().getCurrentUser().getUid());
						MapChatPrivate.put("remetente", FirebaseAuth.getInstance().getCurrentUser().getUid());
						MapChatPrivate.put("enviado", UserNameVerific);
						MapChatPrivate.put("recebendo", textview_username.getText().toString());
						MapChatPrivate.put("lkPhoto", PhotoUserOne);
						MapChatPrivate.put("receptor", getIntent().getStringExtra("secondUser"));
						chat.push().updateChildren(MapChatPrivate);
						chat2.push().updateChildren(MapChatPrivate);
						fbUserInbox.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(MapChatPrivate);
						FilesN = "";
						FilesC = "";
					}
					else {
						MapChatPrivate = new HashMap<>();
						MapChatPrivate.put("PrivateFile", _downloadUrl);
						MapChatPrivate.put("aqv", "Music");
						MapChatPrivate.put("aqvN", MusicName);
						MapChatPrivate.put("UidMsg", FirebaseAuth.getInstance().getCurrentUser().getUid());
						MapChatPrivate.put("remetente", FirebaseAuth.getInstance().getCurrentUser().getUid());
						MapChatPrivate.put("enviado", UserNameVerific);
						MapChatPrivate.put("recebendo", textview_username.getText().toString());
						MapChatPrivate.put("lkPhoto", PhotoUserOne);
						MapChatPrivate.put("receptor", getIntent().getStringExtra("secondUser"));
						chat.push().updateChildren(MapChatPrivate);
						chat2.push().updateChildren(MapChatPrivate);
						fbUserInbox.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(MapChatPrivate);
						FilesN = "";
						FilesC = "";
						MusicName = "";
					}
				}
				else {
					MapChatPrivate = new HashMap<>();
					MapChatPrivate.put("PrivateFile", _downloadUrl);
					MapChatPrivate.put("aqv", "Photo");
					MapChatPrivate.put("legend", legendPhoto);
					MapChatPrivate.put("preview", setCheckedPreview);
					MapChatPrivate.put("aqvN", PhotoN);
					MapChatPrivate.put("UidMsg", FirebaseAuth.getInstance().getCurrentUser().getUid());
					MapChatPrivate.put("remetente", FirebaseAuth.getInstance().getCurrentUser().getUid());
					MapChatPrivate.put("enviado", UserNameVerific);
					MapChatPrivate.put("recebendo", textview_username.getText().toString());
					MapChatPrivate.put("lkPhoto", PhotoUserOne);
					MapChatPrivate.put("receptor", getIntent().getStringExtra("secondUser"));
					chat.push().updateChildren(MapChatPrivate);
					chat2.push().updateChildren(MapChatPrivate);
					fbUserInbox.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(MapChatPrivate);
					FilesN = "";
					FilesC = "";
					PhotoN = "";
				}
			}
		};
		
		_FilesChatPrivate_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				SketchwareUtil.showMessage(getApplicationContext(), "Salvo na pasta StoreMods/Media");
				ProgressDonwload = 0;
			}
		};
		
		_FilesChatPrivate_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_FilesChatPrivate_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		user_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		user_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_user_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_user_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_user_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		listview1.setStackFromBottom(true);
		listview1.setDivider(null);
		listview1.setDividerHeight(0);
		chat.removeEventListener(_chat_child_listener);
		chat2.removeEventListener(_chat2_child_listener);
		Chat1 = "Chat1/".concat(getIntent().getStringExtra("OneUser").concat("/".concat(getIntent().getStringExtra("secondUser"))));
		Chat2 = "Chat1/".concat(getIntent().getStringExtra("secondUser").concat("/".concat(getIntent().getStringExtra("OneUser"))));
		chat=_firebase.getReference(Chat1);
		chat2=_firebase.getReference(Chat2);
		chat.addChildEventListener(_chat_child_listener);
		chat2.addChildEventListener(_chat2_child_listener);
		UserNameVerific = ChatSp.getString("ChatUser", "");
		if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/StoreMods/Media/"))) {
			
		}
		else {
			FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/StoreMods/Media/"));
		}
		ProgressDonwload = 0;
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_IMGFILES:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				FilesN = Uri.parse(Uri.parse(_filePath.get((int)(0))).getLastPathSegment()).getLastPathSegment();
				FilesC = _filePath.get((int)(0));
				FilesChatPrivate.child(FilesN).putFile(Uri.fromFile(new File(FilesC))).addOnFailureListener(_FilesChatPrivate_failure_listener).addOnProgressListener(_FilesChatPrivate_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return FilesChatPrivate.child(FilesN).getDownloadUrl();
					}}).addOnCompleteListener(_FilesChatPrivate_upload_success_listener);
			}
			else {
				
			}
			break;
			
			case REQ_CD_IMGMUSIC:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				MusicName = Uri.parse(Uri.parse(_filePath.get((int)(0))).getLastPathSegment()).getLastPathSegment();
				FilesC = _filePath.get((int)(0));
				FilesChatPrivate.child(MusicName).putFile(Uri.fromFile(new File(FilesC))).addOnFailureListener(_FilesChatPrivate_failure_listener).addOnProgressListener(_FilesChatPrivate_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return FilesChatPrivate.child(MusicName).getDownloadUrl();
					}}).addOnCompleteListener(_FilesChatPrivate_upload_success_listener);
			}
			else {
				
			}
			break;
			
			case REQ_CD_IMGPHOTOS:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				PhotoN = Uri.parse(Uri.parse(_filePath.get((int)(0))).getLastPathSegment()).getLastPathSegment();
				FilesC = _filePath.get((int)(0));
				final com.google.android.material.bottomsheet.BottomSheetDialog SendPhotos = new
				com.google.android.material.bottomsheet.BottomSheetDialog(ChatPrivateActivity.this);
				View lay = getLayoutInflater().inflate(R.layout.custom_send_photos, null); SendPhotos.setContentView(lay);
				final Switch Swt = lay.findViewById(R.id.switch_Borrar);
				final Button sendPhoto = lay.findViewById(R.id.button_send);
				final EditText Legenda = lay.findViewById(R.id.edittext_legenda);
				final ImageView Preview = lay.findViewById(R.id.imageview_Preview);
				Preview.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(FilesC, 1024, 1024));
				setCheckedPreview = "false";
				Swt.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (BooleanChecked) {
							BooleanChecked = false;
							setCheckedPreview = "false";
							Swt.setChecked(false);
						}
						else {
							BooleanChecked = true;
							setCheckedPreview = "true";
							Swt.setChecked(true);
						}
					}
				});
				sendPhoto.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (Legenda.getText().toString().equals("")) {
							legendPhoto = "false";
						}
						else {
							legendPhoto = Legenda.getText().toString();
						}
						FilesChatPrivate.child(PhotoN).putFile(Uri.fromFile(new File(FilesC))).addOnFailureListener(_FilesChatPrivate_failure_listener).addOnProgressListener(_FilesChatPrivate_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
							@Override
							public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
								return FilesChatPrivate.child(PhotoN).getDownloadUrl();
							}}).addOnCompleteListener(_FilesChatPrivate_upload_success_listener);
						SendPhotos.dismiss();
					}
				});
				SendPhotos.show();
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	public void _DesingChat() {
		linear_baseMsg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)22, (int)2, 0xFFFFFFFF, 0xB1000000));
	}
	
	
	public void _SetCaracterPrivateChat() {
		
	}
	
	
	public void _Cryptography() {
	}
	public String EcryptingTheTextMethod(final String _string, final String _key) {
				try{
			javax.crypto.SecretKey key = generateKey(_key);
			javax.crypto.Cipher c = javax.crypto.Cipher.getInstance("AES");
			c.init(javax.crypto.Cipher.ENCRYPT_MODE, key);
			byte[] encVal = c.doFinal(_string.getBytes());
			return android.util.Base64.encodeToString(encVal,android.util.Base64.DEFAULT);
				} catch (Exception e) {
				}
		return "";
		}
	
		public String DecryptingTheTextMethod(final String _string, final String _key) {
				try {
			javax.crypto.spec.SecretKeySpec key = (javax.crypto.spec.SecretKeySpec) generateKey(_key);
			javax.crypto.Cipher c = javax.crypto.Cipher.getInstance("AES");
			c.init(javax.crypto.Cipher.DECRYPT_MODE,key);
			byte[] decode = android.util.Base64.decode(_string,android.util.Base64.DEFAULT);
			byte[] decval = c.doFinal(decode);
			return new String(decval);
				} catch (Exception ex) {
				}
		return "";
		}
		public static javax.crypto.SecretKey generateKey(String pwd) throws Exception {
		final java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
		byte[] b = pwd.getBytes("UTF-8");
		digest.update(b,0,b.length);
		byte[] key = digest.digest();
		javax.crypto.spec.SecretKeySpec sec = new javax.crypto.spec.SecretKeySpec(key, "AES");
		return sec;
		}
	{
	}
	
	
	public void _Notification_Files_forTitle(final String _Title, final String _percentage) {
				{final Activity activity = ChatPrivateActivity.this;
					final Context context = activity.getApplicationContext();
					final int notificationId = 01;
					final String channelId = "5";
					final String channelName = "NotificationFiles";
					
					new androidx.core.app.NotificationCompat.Builder(context, channelId){
							
							
							NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
							Intent intent335 = new Intent();
													   public void create(){
					
															   intent335.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP); 
															   PendingIntent pendingIntent = PendingIntent.getActivity(activity, 0, intent335, 0);
															   
															   if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
																	   NotificationChannel mChannel = new NotificationChannel(
																		   channelId, channelName, NotificationManager.IMPORTANCE_HIGH);
																	   notificationManager.createNotificationChannel(mChannel);
																   }
														
					
					setSmallIcon(R.drawable.ic_folder_open_black);
					setContentTitle(_Title);
					setContentText(_percentage);
															   setAutoCancel(true);
					notificationManager.notify(notificationId, this.build());
					
														   }
				
												   }.create();}
				
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.private_chat_custom, null);
			}
			
			final LinearLayout linear_BaseMsgYour = _view.findViewById(R.id.linear_BaseMsgYour);
			final LinearLayout linear_BaseArquivosYour = _view.findViewById(R.id.linear_BaseArquivosYour);
			final LinearLayout linear_BaseMusicYour = _view.findViewById(R.id.linear_BaseMusicYour);
			final LinearLayout linear_basePreviewYour = _view.findViewById(R.id.linear_basePreviewYour);
			final LinearLayout linear_BasePreviewMy = _view.findViewById(R.id.linear_BasePreviewMy);
			final LinearLayout linear_BaseMusicMy = _view.findViewById(R.id.linear_BaseMusicMy);
			final LinearLayout linear_BaseArquivosMy = _view.findViewById(R.id.linear_BaseArquivosMy);
			final LinearLayout linear_BaseMsgMy = _view.findViewById(R.id.linear_BaseMsgMy);
			final LinearLayout linear_yourmsg = _view.findViewById(R.id.linear_yourmsg);
			final TextView textview_yourMsg = _view.findViewById(R.id.textview_yourMsg);
			final LinearLayout linear_aqvs_yours = _view.findViewById(R.id.linear_aqvs_yours);
			final ImageView imageview_aqvs_your = _view.findViewById(R.id.imageview_aqvs_your);
			final TextView textview_name_aqvs_your = _view.findViewById(R.id.textview_name_aqvs_your);
			final ImageView imageview_yourDonwload = _view.findViewById(R.id.imageview_yourDonwload);
			final LinearLayout linear_audio_your = _view.findViewById(R.id.linear_audio_your);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final SeekBar seekbar_your = _view.findViewById(R.id.seekbar_your);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview_nameMusicYour = _view.findViewById(R.id.textview_nameMusicYour);
			final ImageView imageview_playYour = _view.findViewById(R.id.imageview_playYour);
			final ImageView imageview_PreviewYour = _view.findViewById(R.id.imageview_PreviewYour);
			final TextView textview_legendYour = _view.findViewById(R.id.textview_legendYour);
			final ImageView imageview_PreviewMy = _view.findViewById(R.id.imageview_PreviewMy);
			final TextView textview_legendMy = _view.findViewById(R.id.textview_legendMy);
			final LinearLayout linear1_audioMy = _view.findViewById(R.id.linear1_audioMy);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final SeekBar seekbar_my = _view.findViewById(R.id.seekbar_my);
			final ImageView imageview_playMy = _view.findViewById(R.id.imageview_playMy);
			final TextView textview_nameMusic = _view.findViewById(R.id.textview_nameMusic);
			final ImageView imageview3 = _view.findViewById(R.id.imageview3);
			final LinearLayout linear_aqvs_my = _view.findViewById(R.id.linear_aqvs_my);
			final ImageView imageview_myDonwload = _view.findViewById(R.id.imageview_myDonwload);
			final TextView textview_name_aqvs_my = _view.findViewById(R.id.textview_name_aqvs_my);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear_mymsg = _view.findViewById(R.id.linear_mymsg);
			final TextView textview_my_msg = _view.findViewById(R.id.textview_my_msg);
			
			linear_aqvs_my.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xB1FFFFFF));
			linear_aqvs_yours.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xB1FFFFFF));
			linear_audio_your.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xB1FFFFFF));
			linear1_audioMy.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xB1FFFFFF));
			linear_yourmsg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xB1FFFFFF));
			linear_basePreviewYour.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xB1FFFFFF));
			linear_BasePreviewMy.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xB1FFFFFF));
			linear_mymsg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xB1FFFFFF));
			if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(_data.get((int)_position).get("UidMsg").toString())) {
				textview_name_aqvs_my.setText("");
				if (_data.get((int)_position).get("aqv").toString().equals("File")) {
					linear_BaseMusicYour.setVisibility(View.GONE);
					linear_BaseArquivosYour.setVisibility(View.GONE);
					linear_BaseMsgYour.setVisibility(View.GONE);
					linear_BasePreviewMy.setVisibility(View.GONE);
					linear_basePreviewYour.setVisibility(View.GONE);
					linear_BaseMusicMy.setVisibility(View.GONE);
					linear_BaseArquivosMy.setVisibility(View.VISIBLE);
					linear_BaseMsgMy.setVisibility(View.GONE);
					textview_name_aqvs_my.setText(_data.get((int)_position).get("aqvN").toString());
				}
				else {
					if (_data.get((int)_position).get("aqv").toString().equals("Music")) {
						linear_BaseArquivosYour.setVisibility(View.GONE);
						linear_BaseMsgYour.setVisibility(View.GONE);
						linear_BaseMusicMy.setVisibility(View.VISIBLE);
						linear_BaseArquivosMy.setVisibility(View.GONE);
						linear_basePreviewYour.setVisibility(View.GONE);
						linear_BasePreviewMy.setVisibility(View.GONE);
						linear_BaseMsgMy.setVisibility(View.GONE);
						linear_BaseMusicYour.setVisibility(View.GONE);
						textview_nameMusic.setText(_data.get((int)_position).get("aqvN").toString());
						imageview_playMy.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								if (PlayMusic2) {
									PlayMusic2 = false;
									seekbar_my.setVisibility(View.GONE);
									imageview_playMy.setImageResource(R.drawable.ic_play_circle_outline_black);
									MediaPlayerStore.pause();
								}
								else {
									PlayMusic2 = true;
									imageview_playMy.setImageResource(R.drawable.ic_pause_circle_outline_black);
									seekbar_my.setVisibility(View.VISIBLE);
									
									
									LoadSekebar = new TimerTask() {
										@Override
										public void run() {
											runOnUiThread(new Runnable() {
												@Override
												public void run() {
													seekbar_my.setMax((int)MediaPlayerStore.getDuration() / 1000);
													seekbar_my.setProgress((int)MediaPlayerStore.getCurrentPosition() / 1000);
												}
											});
										}
									};
									_timer.scheduleAtFixedRate(LoadSekebar, (int)(0), (int)(10));
								}
							}
						});
					}
					if (_data.get((int)_position).get("aqv").toString().equals("Photo")) {
						linear_BaseMusicYour.setVisibility(View.GONE);
						linear_BaseArquivosYour.setVisibility(View.GONE);
						linear_BaseMsgYour.setVisibility(View.GONE);
						linear_BaseMusicMy.setVisibility(View.GONE);
						linear_basePreviewYour.setVisibility(View.GONE);
						linear_BasePreviewMy.setVisibility(View.VISIBLE);
						linear_BaseArquivosMy.setVisibility(View.GONE);
						linear_BaseMsgMy.setVisibility(View.GONE);
						if (_data.get((int)_position).get("legend").toString().equals("false")) {
							textview_legendMy.setVisibility(View.GONE);
						}
						else {
							textview_legendMy.setVisibility(View.VISIBLE);
							textview_legendMy.setText(_data.get((int)_position).get("legend").toString());
						}
						if (_data.get((int)_position).get("preview").toString().equals("false")) {
							Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("PrivateFile").toString())).into(imageview_PreviewMy);
						}
						else {
							if (_data.get((int)_position).get("preview").toString().equals("true")) {
								imageview_PreviewMy.setImageResource(R.drawable.ic_visibility_off_black);
							}
						}
						imageview_PreviewMy.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								txP.setClass(getApplicationContext(), ViewPhotoActivity.class);
								txP.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								txP.putExtra("DonwloadPhoto", _data.get((int)_position).get("PrivateFile").toString());
								txP.putExtra("PhotoName", _data.get((int)_position).get("aqvN").toString());
								startActivity(txP);
							}
						});
					}
				}
				if (_data.get((int)_position).get("aqv").toString().equals("NoFile")) {
					linear_BaseMusicYour.setVisibility(View.GONE);
					linear_BaseArquivosYour.setVisibility(View.GONE);
					linear_BaseMsgYour.setVisibility(View.GONE);
					linear_BaseMusicMy.setVisibility(View.GONE);
					linear_basePreviewYour.setVisibility(View.GONE);
					linear_BasePreviewMy.setVisibility(View.GONE);
					linear_BaseArquivosMy.setVisibility(View.GONE);
					linear_BaseMsgMy.setVisibility(View.VISIBLE);
					textview_my_msg.setText(_data.get((int)_position).get("PrivateMsg").toString());
				}
			}
			else {
				if (_data.get((int)_position).get("aqv").toString().equals("File")) {
					linear_BaseMusicYour.setVisibility(View.GONE);
					linear_BaseArquivosYour.setVisibility(View.VISIBLE);
					linear_BaseMsgYour.setVisibility(View.GONE);
					linear_BaseMusicMy.setVisibility(View.GONE);
					linear_basePreviewYour.setVisibility(View.GONE);
					linear_BasePreviewMy.setVisibility(View.GONE);
					linear_BaseArquivosMy.setVisibility(View.GONE);
					linear_BaseMsgMy.setVisibility(View.GONE);
					textview_name_aqvs_your.setText(_data.get((int)_position).get("aqvN").toString());
				}
				else {
					if (_data.get((int)_position).get("aqv").toString().equals("Music")) {
						linear_BaseMusicYour.setVisibility(View.VISIBLE);
						linear_BaseArquivosYour.setVisibility(View.GONE);
						linear_BaseMsgYour.setVisibility(View.GONE);
						linear_BaseMusicMy.setVisibility(View.GONE);
						linear_BaseArquivosMy.setVisibility(View.GONE);
						linear_basePreviewYour.setVisibility(View.GONE);
						linear_BasePreviewMy.setVisibility(View.GONE);
						linear_BaseMsgMy.setVisibility(View.GONE);
						textview_nameMusicYour.setText(_data.get((int)_position).get("aqvN").toString());
						imageview_playYour.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								if (PlayMusic) {
									PlayMusic = false;
									seekbar_your.setVisibility(View.GONE);
									imageview_playYour.setImageResource(R.drawable.ic_play_circle_outline_black);
									MediaPlayerStore.pause();
								}
								else {
									PlayMusic = true;
									imageview_playYour.setImageResource(R.drawable.ic_pause_circle_outline_black);
									seekbar_your.setVisibility(View.VISIBLE);
									
									
									LoadSekebar = new TimerTask() {
										@Override
										public void run() {
											runOnUiThread(new Runnable() {
												@Override
												public void run() {
													seekbar_your.setMax((int)MediaPlayerStore.getDuration() / 1000);
													seekbar_your.setProgress((int)MediaPlayerStore.getCurrentPosition() / 1000);
												}
											});
										}
									};
									_timer.scheduleAtFixedRate(LoadSekebar, (int)(0), (int)(10));
								}
							}
						});
					}
					if (_data.get((int)_position).get("aqv").toString().equals("Photo")) {
						linear_BaseMusicYour.setVisibility(View.GONE);
						linear_BaseArquivosYour.setVisibility(View.GONE);
						linear_BaseMsgYour.setVisibility(View.GONE);
						linear_BaseMusicMy.setVisibility(View.GONE);
						linear_basePreviewYour.setVisibility(View.VISIBLE);
						linear_BasePreviewMy.setVisibility(View.GONE);
						linear_BaseArquivosMy.setVisibility(View.GONE);
						linear_BaseMsgMy.setVisibility(View.GONE);
						if (_data.get((int)_position).get("legend").toString().equals("false")) {
							textview_legendYour.setVisibility(View.GONE);
						}
						else {
							textview_legendYour.setVisibility(View.VISIBLE);
							textview_legendYour.setText(_data.get((int)_position).get("legend").toString());
						}
						if (_data.get((int)_position).get("preview").toString().equals("false")) {
							Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("PrivateFile").toString())).into(imageview_PreviewYour);
						}
						else {
							if (_data.get((int)_position).get("preview").toString().equals("true")) {
								imageview_PreviewYour.setImageResource(R.drawable.ic_visibility_off_black);
							}
						}
						imageview_PreviewYour.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								txP.setClass(getApplicationContext(), ViewPhotoActivity.class);
								txP.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								txP.putExtra("DonwloadPhoto", _data.get((int)_position).get("PrivateFile").toString());
								txP.putExtra("PhotoName", _data.get((int)_position).get("aqvN").toString());
								startActivity(txP);
							}
						});
					}
				}
				if (_data.get((int)_position).get("aqv").toString().equals("NoFile")) {
					linear_BaseMusicYour.setVisibility(View.GONE);
					linear_BaseArquivosYour.setVisibility(View.GONE);
					linear_BaseMsgYour.setVisibility(View.VISIBLE);
					linear_BaseMusicMy.setVisibility(View.GONE);
					linear_basePreviewYour.setVisibility(View.GONE);
					linear_BasePreviewMy.setVisibility(View.GONE);
					linear_BaseArquivosMy.setVisibility(View.GONE);
					linear_BaseMsgMy.setVisibility(View.GONE);
					textview_yourMsg.setText(_data.get((int)_position).get("PrivateMsg").toString());
				}
			}
			imageview_yourDonwload.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_firebase_storage.getReferenceFromUrl(ListMapPrivateChat.get((int)_position).get("PrivateFile").toString()).getFile(new File(FileUtil.getExternalStorageDir().concat("/StoreMods/Media/").concat(ListMapPrivateChat.get((int)_position).get("aqvN").toString()))).addOnSuccessListener(_FilesChatPrivate_download_success_listener).addOnFailureListener(_FilesChatPrivate_failure_listener).addOnProgressListener(_FilesChatPrivate_download_progress_listener);
					SketchwareUtil.showMessage(getApplicationContext(), "Baixando Aguarde...");
				}
			});
			imageview_myDonwload.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_firebase_storage.getReferenceFromUrl(ListMapPrivateChat.get((int)_position).get("PrivateFile").toString()).getFile(new File(FileUtil.getExternalStorageDir().concat("/StoreMods/Media/").concat(ListMapPrivateChat.get((int)_position).get("aqvN").toString()))).addOnSuccessListener(_FilesChatPrivate_download_success_listener).addOnFailureListener(_FilesChatPrivate_failure_listener).addOnProgressListener(_FilesChatPrivate_download_progress_listener);
					SketchwareUtil.showMessage(getApplicationContext(), "Baixando Aguarde...");
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}