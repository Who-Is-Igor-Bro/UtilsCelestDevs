package com.LojaMods.TexasCorp;

import android.Manifest;
import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.File;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class CreateStandLayoutActivity extends AppCompatActivity {
	
	public final int REQ_CD_FILEPICKER = 101;
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private HashMap<String, Object> Maps = new HashMap<>();
	private HashMap<String, Object> MapStand = new HashMap<>();
	private double Cont = 0;
	private String Nome_P = "";
	private String caminho_P = "";
	
	private ArrayList<String> str = new ArrayList<>();
	
	private ScrollView vscroll2;
	private LinearLayout linear15;
	private LinearLayout linear_back;
	private LinearLayout linear_photoFudo;
	private LinearLayout linear3;
	private CircleImageView circleimageview1;
	private TextView textview2;
	private LinearLayout linear_email;
	private LinearLayout linear_senha;
	private LinearLayout linear_nome;
	private LinearLayout linear_descricao;
	private LinearLayout linear13;
	private EditText edittext_email;
	private EditText edittext_senha;
	private TextView textview_contadorCaracter;
	private EditText edittext_nome;
	private EditText edittext_descricao;
	private Button button1;
	private TextView textview3;
	
	private DatabaseReference FbStand = _firebase.getReference("Stand");
	private ChildEventListener _FbStand_child_listener;
	private StorageReference FbPhoto = _firebase_storage.getReference("Photo");
	private OnCompleteListener<Uri> _FbPhoto_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _FbPhoto_download_success_listener;
	private OnSuccessListener _FbPhoto_delete_success_listener;
	private OnProgressListener _FbPhoto_upload_progress_listener;
	private OnProgressListener _FbPhoto_download_progress_listener;
	private OnFailureListener _FbPhoto_failure_listener;
	
	private FirebaseAuth user;
	private OnCompleteListener<AuthResult> _user_create_user_listener;
	private OnCompleteListener<AuthResult> _user_sign_in_listener;
	private OnCompleteListener<Void> _user_reset_password_listener;
	private OnCompleteListener<Void> user_updateEmailListener;
	private OnCompleteListener<Void> user_updatePasswordListener;
	private OnCompleteListener<Void> user_emailVerificationSentListener;
	private OnCompleteListener<Void> user_deleteUserListener;
	private OnCompleteListener<Void> user_updateProfileListener;
	private OnCompleteListener<AuthResult> user_phoneAuthListener;
	private OnCompleteListener<AuthResult> user_googleSignInListener;
	
	private Intent FilePicker = new Intent(Intent.ACTION_GET_CONTENT);
	private AlertDialog.Builder Dg;
	private SharedPreferences Uid;
	private ObjectAnimator Animation = new ObjectAnimator();
	private Intent telas = new Intent();
	private SharedPreferences PhotoDb;
	private SharedPreferences CaracterCount;
	private Notification Notification_CreateAccount;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.create_stand_layout);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll2 = findViewById(R.id.vscroll2);
		linear15 = findViewById(R.id.linear15);
		linear_back = findViewById(R.id.linear_back);
		linear_photoFudo = findViewById(R.id.linear_photoFudo);
		linear3 = findViewById(R.id.linear3);
		circleimageview1 = findViewById(R.id.circleimageview1);
		textview2 = findViewById(R.id.textview2);
		linear_email = findViewById(R.id.linear_email);
		linear_senha = findViewById(R.id.linear_senha);
		linear_nome = findViewById(R.id.linear_nome);
		linear_descricao = findViewById(R.id.linear_descricao);
		linear13 = findViewById(R.id.linear13);
		edittext_email = findViewById(R.id.edittext_email);
		edittext_senha = findViewById(R.id.edittext_senha);
		textview_contadorCaracter = findViewById(R.id.textview_contadorCaracter);
		edittext_nome = findViewById(R.id.edittext_nome);
		edittext_descricao = findViewById(R.id.edittext_descricao);
		button1 = findViewById(R.id.button1);
		textview3 = findViewById(R.id.textview3);
		user = FirebaseAuth.getInstance();
		FilePicker.setType("image/*");
		FilePicker.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		Dg = new AlertDialog.Builder(this);
		Uid = getSharedPreferences("Uid", Activity.MODE_PRIVATE);
		PhotoDb = getSharedPreferences("PhotoUser", Activity.MODE_PRIVATE);
		CaracterCount = getSharedPreferences("CountCaracter", Activity.MODE_PRIVATE);
		
		circleimageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(FilePicker, REQ_CD_FILEPICKER);
			}
		});
		
		linear_senha.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		edittext_senha.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		edittext_senha.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				textview_contadorCaracter.setText(String.valueOf((long)(_charSeq.length())));
				if (_charSeq.length() > Cont) {
					textview_contadorCaracter.setTextColor(0xFF43A047);
				}
				else {
					textview_contadorCaracter.setTextColor(0xFFF44336);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext_email.getText().toString().equals("")) {
					edittext_email.setError("Preencha esse campo com seu e-mail.");
				}
				else {
					if (edittext_senha.getText().toString().equals("")) {
						edittext_senha.setError("Preencha esse campo com sua senha.");
					}
					else {
						if (edittext_nome.getText().toString().equals("")) {
							edittext_descricao.setError("Preencha esse campo com seu nomem");
						}
						else {
							if (edittext_descricao.getText().toString().equals("")) {
								edittext_nome.setError("Preencha esse campo com sua descrição.");
							}
							else {
								if (Nome_P.equals("") || caminho_P.equals("")) {
									SketchwareUtil.showMessage(getApplicationContext(), "selecione uma imagem!");
								}
								else {
									if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
										SketchwareUtil.showMessage(getApplicationContext(), "você ja está logado!");
									}
									else {
										user.createUserWithEmailAndPassword(edittext_email.getText().toString(), edittext_senha.getText().toString()).addOnCompleteListener(CreateStandLayoutActivity.this, _user_create_user_listener);
										FbPhoto.child(Nome_P).putFile(Uri.fromFile(new File(caminho_P))).addOnFailureListener(_FbPhoto_failure_listener).addOnProgressListener(_FbPhoto_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
											@Override
											public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
												return FbPhoto.child(Nome_P).getDownloadUrl();
											}}).addOnCompleteListener(_FbPhoto_upload_success_listener);
									}
								}
							}
						}
					}
				}
			}
		});
		
		textview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
					SketchwareUtil.showMessage(getApplicationContext(), "Você ja está logado");
				}
				else {
					telas.setClass(getApplicationContext(), EntrarAccountLayoutActivity.class);
					startActivity(telas);
				}
			}
		});
		
		_FbStand_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		FbStand.addChildEventListener(_FbStand_child_listener);
		
		_FbPhoto_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				_Notification_create_account("Criado sua conta!", "Progresso".concat(" ".concat(String.valueOf((long)(_progressValue)))));
			}
		};
		
		_FbPhoto_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_FbPhoto_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				MapStand = new HashMap<>();
				MapStand.put("photo_lk", _downloadUrl);
				MapStand.put("name_stand", edittext_nome.getText().toString());
				MapStand.put("descri_stand", edittext_descricao.getText().toString());
				MapStand.put("verifc", "");
				MapStand.put("buildUser", Build.ID);
				MapStand.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				FbStand.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(MapStand);
				edittext_email.setText("");
				edittext_senha.setText("");
				edittext_nome.setText("");
				edittext_descricao.setText("");
				telas.setClass(getApplicationContext(), LayoutMenuActivity.class);
				_Notification_create_account("Sua conta foi criada!", "Aproveite nosso aplicativo!");
				PhotoDb.edit().putString("UserPhotoDb", FirebaseAuth.getInstance().getCurrentUser().getUid()).commit();
				startActivity(telas);
			}
		};
		
		_FbPhoto_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_FbPhoto_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_FbPhoto_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		user_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		user_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_user_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					SketchwareUtil.showMessage(getApplicationContext(), "Perfil criado,aguarde mais um pouco!");
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		_user_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_user_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		setTitle("Criar conta");
		vscroll2.setBackgroundDrawable(getResources().getDrawable(R.drawable.background_loggin_layout));
		Cont = 6;
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FILEPICKER:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				caminho_P = _filePath.get((int)(0));
				Nome_P = Uri.parse(Uri.parse(_filePath.get((int)(0))).getLastPathSegment()).getLastPathSegment();
				circleimageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_filePath.get((int)(0)), 1024, 1024));
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	public void _Desing() {
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)22, (int)4, 0xFF000000, 0xFFBDBDBD));
		linear_photoFudo.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)5, 0xFF000000, 0xB1000000));
		linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)5, 0xFF000000, 0xB1000000));
		edittext_email.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xB1FFFFFF));
		edittext_senha.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xB1FFFFFF));
		edittext_nome.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xB1FFFFFF));
		edittext_descricao.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xB1FFFFFF));
		textview_contadorCaracter.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xB1FFFFFF));
	}
	
	
	public void _Notification_create_account(final String _title, final String _text) {
				{final Activity activity = CreateStandLayoutActivity.this;
					final Context context = activity.getApplicationContext();
					final int notificationId = 01;
					final String channelId = "1";
					final String channelName = "Notification_CreateAccount";
					
					new androidx.core.app.NotificationCompat.Builder(context, channelId){
							
							
							NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
							Intent intent335 = new Intent();
													   public void create(){
					
															   intent335.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP); 
															   PendingIntent pendingIntent = PendingIntent.getActivity(activity, 0, intent335, 0);
															   
															   if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
																	   NotificationChannel mChannel = new NotificationChannel(
																		   channelId, channelName, NotificationManager.IMPORTANCE_HIGH);
																	   notificationManager.createNotificationChannel(mChannel);
																   }
														
					
					setSmallIcon(R.drawable.ic_dvr_black);
					setContentTitle(_title);
					setContentText(_text);
															   setAutoCancel(true);
					notificationManager.notify(notificationId, this.build());
					
														   }
				
												   }.create();}
				
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}