package com.LojaMods.TexasCorp;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.File;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class CreateTeamFragmentActivity extends Fragment {
	
	public final int REQ_CD_TEAMPHOTOCREATE = 101;
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private String P_c = "";
	private String P_n = "";
	private String keyTeamCheck = "";
	private String nameT = "";
	private String desT = "";
	private String keyT = "";
	private HashMap<String, Object> MapCreateTeams = new HashMap<>();
	private boolean ClickRaddioButton = false;
	private boolean ClickRaddio2 = false;
	
	private ArrayList<String> StrTeamString = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear3;
	private CircleImageView circleimageview1;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private CheckBox checkbox1;
	private LinearLayout linear2;
	private Button button1;
	private EditText edittext_T_name;
	private EditText edittext_t_des;
	private EditText edittext_t_key;
	
	private StorageReference CreateTeam = _firebase_storage.getReference("TeamStorage");
	private OnCompleteListener<Uri> _CreateTeam_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _CreateTeam_download_success_listener;
	private OnSuccessListener _CreateTeam_delete_success_listener;
	private OnProgressListener _CreateTeam_upload_progress_listener;
	private OnProgressListener _CreateTeam_download_progress_listener;
	private OnFailureListener _CreateTeam_failure_listener;
	
	private DatabaseReference CreatingTeams = _firebase.getReference("AdminCheckTeams");
	private ChildEventListener _CreatingTeams_child_listener;
	private Intent TeamPhotoCreate = new Intent(Intent.ACTION_GET_CONTENT);
	private FirebaseAuth user;
	private OnCompleteListener<AuthResult> _user_create_user_listener;
	private OnCompleteListener<AuthResult> _user_sign_in_listener;
	private OnCompleteListener<Void> _user_reset_password_listener;
	private OnCompleteListener<Void> user_updateEmailListener;
	private OnCompleteListener<Void> user_updatePasswordListener;
	private OnCompleteListener<Void> user_emailVerificationSentListener;
	private OnCompleteListener<Void> user_deleteUserListener;
	private OnCompleteListener<Void> user_updateProfileListener;
	private OnCompleteListener<AuthResult> user_phoneAuthListener;
	private OnCompleteListener<AuthResult> user_googleSignInListener;
	
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.create_team_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		linear1 = _view.findViewById(R.id.linear1);
		linear3 = _view.findViewById(R.id.linear3);
		circleimageview1 = _view.findViewById(R.id.circleimageview1);
		linear4 = _view.findViewById(R.id.linear4);
		linear5 = _view.findViewById(R.id.linear5);
		checkbox1 = _view.findViewById(R.id.checkbox1);
		linear2 = _view.findViewById(R.id.linear2);
		button1 = _view.findViewById(R.id.button1);
		edittext_T_name = _view.findViewById(R.id.edittext_T_name);
		edittext_t_des = _view.findViewById(R.id.edittext_t_des);
		edittext_t_key = _view.findViewById(R.id.edittext_t_key);
		TeamPhotoCreate.setType("image/*");
		TeamPhotoCreate.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		user = FirebaseAuth.getInstance();
		
		circleimageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(TeamPhotoCreate, REQ_CD_TEAMPHOTOCREATE);
			}
		});
		
		checkbox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					checkbox1.setChecked(true);
					keyTeamCheck = "true";
					linear2.setVisibility(View.VISIBLE);
				}
				else {
					checkbox1.setChecked(false);
					keyTeamCheck = "false";
					linear2.setVisibility(View.GONE);
				}
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (P_n.equals("")) {
					SketchwareUtil.showMessage(getContext().getApplicationContext(), "Selecione uma foto");
				}
				else {
					if (keyTeamCheck.equals("true")) {
						if (edittext_T_name.getText().toString().equals("")) {
							edittext_T_name.setError("Sem nome!");
						}
						else {
							if (edittext_t_des.getText().toString().equals("")) {
								edittext_t_des.setError("Sem definição!");
							}
							else {
								if (edittext_t_key.getText().toString().equals("")) {
									edittext_t_key.setError("Sem a Chave de acesso da Team!");
								}
								else {
									nameT = edittext_T_name.getText().toString();
									desT = edittext_t_des.getText().toString();
									keyT = edittext_t_key.getText().toString();
									CreateTeam.child(P_n).putFile(Uri.fromFile(new File(P_c))).addOnFailureListener(_CreateTeam_failure_listener).addOnProgressListener(_CreateTeam_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
										@Override
										public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
											return CreateTeam.child(P_n).getDownloadUrl();
										}}).addOnCompleteListener(_CreateTeam_upload_success_listener);
								}
							}
						}
					}
					else {
						if (edittext_T_name.getText().toString().equals("")) {
							edittext_T_name.setError("Sem nome!");
						}
						else {
							if (edittext_t_des.getText().toString().equals("")) {
								edittext_t_des.setError("Sem definição!");
							}
							else {
								nameT = edittext_T_name.getText().toString();
								desT = edittext_t_des.getText().toString();
								CreateTeam.child(P_n).putFile(Uri.fromFile(new File(P_c))).addOnFailureListener(_CreateTeam_failure_listener).addOnProgressListener(_CreateTeam_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
									@Override
									public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
										return CreateTeam.child(P_n).getDownloadUrl();
									}}).addOnCompleteListener(_CreateTeam_upload_success_listener);
							}
						}
					}
				}
			}
		});
		
		_CreateTeam_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				SketchwareUtil.showMessage(getContext().getApplicationContext(), "Enviando %".concat(String.valueOf((long)(_progressValue))));
			}
		};
		
		_CreateTeam_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_CreateTeam_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				if (keyTeamCheck.equals("true")) {
					MapCreateTeams = new HashMap<>();
					MapCreateTeams.put("TeamName", nameT);
					MapCreateTeams.put("TeamDefinicao", desT);
					MapCreateTeams.put("TeamPrivate", "true");
					MapCreateTeams.put("status", "Pendente");
					MapCreateTeams.put("TeamPrivateKey", keyT);
					MapCreateTeams.put("TeamProfileLk", _downloadUrl);
					MapCreateTeams.put("idCreator", FirebaseAuth.getInstance().getCurrentUser().getUid());
					CreatingTeams.child(nameT).updateChildren(MapCreateTeams);
					SketchwareUtil.showMessage(getContext().getApplicationContext(), "Sua Team será Verificada, Enviaremos um aviso a você se ela for aceita.");
				}
				else {
					if (keyTeamCheck.equals("false")) {
						MapCreateTeams = new HashMap<>();
						MapCreateTeams.put("TeamName", nameT);
						MapCreateTeams.put("TeamDefinicao", desT);
						MapCreateTeams.put("TeamPrivate", "false");
						MapCreateTeams.put("status", "Pendente");
						MapCreateTeams.put("TeamProfileLk", _downloadUrl);
						MapCreateTeams.put("idCreator", FirebaseAuth.getInstance().getCurrentUser().getUid());
						CreatingTeams.child(nameT).updateChildren(MapCreateTeams);
						SketchwareUtil.showMessage(getContext().getApplicationContext(), "Sua Team será Verificada, Enviaremos um aviso a você se ela for aceita.");
					}
				}
			}
		};
		
		_CreateTeam_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_CreateTeam_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_CreateTeam_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_CreatingTeams_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		CreatingTeams.addChildEventListener(_CreatingTeams_child_listener);
		
		user_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		user_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_user_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_user_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_user_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		linear2.setVisibility(View.GONE);
		keyTeamCheck = "false";
	}
	
	@Override
	public void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_TEAMPHOTOCREATE:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getContext().getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getContext().getApplicationContext(), _data.getData()));
					}
				}
				P_c = _filePath.get((int)(0));
				P_n = Uri.parse(Uri.parse(_filePath.get((int)(0))).getLastPathSegment()).getLastPathSegment();
				circleimageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_filePath.get((int)(0)), 1024, 1024));
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	public void _DesinCreateTeam() {
		linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)2, 0xFFFFFFFF, Color.TRANSPARENT));
		linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)2, 0xFFFFFFFF, Color.TRANSPARENT));
		linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)2, 0xFFFFFFFF, Color.TRANSPARENT));
		linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)18, (int)3, 0xFFFFFFFF, 0xB1000000));
	}
	
}