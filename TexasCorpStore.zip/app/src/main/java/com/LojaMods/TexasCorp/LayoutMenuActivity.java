package com.LojaMods.TexasCorp;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.media.MediaPlayer;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.File;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class LayoutMenuActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private DrawerLayout _drawer;
	private HashMap<String, Object> map = new HashMap<>();
	private String str = "";
	private double number = 0;
	private HashMap<String, Object> TopMapUser = new HashMap<>();
	private HashMap<String, Object> mapBan = new HashMap<>();
	private HashMap<String, Object> MapEvente = new HashMap<>();
	private String One1 = "";
	private String Two2 = "";
	private String three3 = "";
	private String nameapp = "";
	private String TopuserName = "";
	private String TopUserC = "";
	private String KeyStorage = "";
	private String Event_True_or_False = "";
	private String EventString = "";
	private String Photo_Link_Donwload = "";
	private boolean MusicEvent = false;
	private HashMap<String, Object> MapEventosStore = new HashMap<>();
	private double getClickGreen = 0;
	private double getClickRed = 0;
	private HashMap<String, Object> VotingMap = new HashMap<>();
	private String childKey = "";
	
	private ArrayList<HashMap<String, Object>> lts = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> TopUsuarios = new ArrayList<>();
	
	private LinearLayout linear_back;
	private TextView textview1;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private Button button1;
	private LinearLayout linear2;
	private TextView textview2;
	private TextView textview3;
	private ScrollView _drawer_vscroll1;
	private LinearLayout _drawer_linear2;
	private TextView _drawer_textview2;
	private CircleImageView _drawer_circleimageview1;
	private TextView _drawer_textview_name_email;
	private LinearLayout _drawer_linear3;
	private LinearLayout _drawer_linear5;
	private LinearLayout _drawer_linear7;
	private LinearLayout _drawer_linear11;
	private LinearLayout _drawer_linear12;
	private LinearLayout _drawer_linear9;
	private LinearLayout _drawer_linear13;
	private LinearLayout _drawer_linear10;
	private LinearLayout _drawer_linear14;
	private LinearLayout _drawer_linear15;
	private LinearLayout _drawer_linear16;
	private LinearLayout _drawer_linear17;
	private LinearLayout _drawer_linear18;
	private LinearLayout _drawer_linear_stand;
	private ImageView _drawer_imageview1;
	private TextView _drawer_textview3;
	private ImageView _drawer_imageview2;
	private LinearLayout _drawer_linear_upload;
	private ImageView _drawer_imageview3;
	private TextView _drawer_textview4;
	private ImageView _drawer_imageview4;
	private LinearLayout _drawer_linear_suport;
	private ImageView _drawer_imageview5;
	private TextView _drawer_textview5;
	private ImageView _drawer_imageview6;
	private LinearLayout _drawer_linear_metodos;
	private ImageView _drawer_imageview11;
	private TextView _drawer_textview8;
	private ImageView _drawer_imageview12;
	private LinearLayout _drawer_linear_globalchat;
	private ImageView _drawer_imageview13;
	private TextView _drawer_textview9;
	private ImageView _drawer_imageview14;
	private LinearLayout _drawer_linear_viewModsStands;
	private ImageView _drawer_imageview7;
	private TextView _drawer_textview6;
	private ImageView _drawer_imageview8;
	private LinearLayout _drawer_linear_msgss;
	private ImageView _drawer_imageview15;
	private TextView _drawer_textview10;
	private ImageView _drawer_imageview16;
	private LinearLayout _drawer_linear_Confi;
	private ImageView _drawer_imageview9;
	private TextView _drawer_textview7;
	private ImageView _drawer_imageview10;
	private LinearLayout _drawer_linear_Parceiros;
	private ImageView _drawer_imageview17;
	private TextView _drawer_textview11;
	private ImageView _drawer_imageview18;
	private LinearLayout _drawer_linear_News;
	private ImageView _drawer_imageview19;
	private TextView _drawer_textview12;
	private ImageView _drawer_imageview20;
	private LinearLayout _drawer_linear_save;
	private ImageView _drawer_imageview21;
	private TextView _drawer_textview13;
	private ImageView _drawer_imageview22;
	private LinearLayout _drawer_linear_ModsWhatsapp;
	private ImageView _drawer_imageview23;
	private TextView _drawer_textview14;
	private ImageView _drawer_imageview24;
	private LinearLayout _drawer_linear_teams;
	private ImageView _drawer_imageview25;
	private TextView _drawer_textview15;
	private ImageView _drawer_imageview26;
	
	private Intent telas = new Intent();
	private DatabaseReference StandView = _firebase.getReference("Stand");
	private ChildEventListener _StandView_child_listener;
	private FirebaseAuth user;
	private OnCompleteListener<AuthResult> _user_create_user_listener;
	private OnCompleteListener<AuthResult> _user_sign_in_listener;
	private OnCompleteListener<Void> _user_reset_password_listener;
	private OnCompleteListener<Void> user_updateEmailListener;
	private OnCompleteListener<Void> user_updatePasswordListener;
	private OnCompleteListener<Void> user_emailVerificationSentListener;
	private OnCompleteListener<Void> user_deleteUserListener;
	private OnCompleteListener<Void> user_updateProfileListener;
	private OnCompleteListener<AuthResult> user_phoneAuthListener;
	private OnCompleteListener<AuthResult> user_googleSignInListener;
	
	private Intent tela = new Intent();
	private AlertDialog.Builder DgAtt;
	private AlertDialog.Builder DgAviso;
	private AlertDialog.Builder DgAccount;
	private TimerTask time;
	private SharedPreferences Uid;
	private DatabaseReference FbAtu = _firebase.getReference("Att");
	private ChildEventListener _FbAtu_child_listener;
	private SharedPreferences ShdA;
	private AlertDialog.Builder Att;
	private Intent link = new Intent();
	private DatabaseReference FbAv = _firebase.getReference("Aviso");
	private ChildEventListener _FbAv_child_listener;
	private AlertDialog.Builder Aviso;
	private SharedPreferences Tems;
	private DatabaseReference TopU = _firebase.getReference("TopUsuarios");
	private ChildEventListener _TopU_child_listener;
	private DatabaseReference FbBanUser = _firebase.getReference("Ban");
	private ChildEventListener _FbBanUser_child_listener;
	private AlertDialog.Builder BanUserDg;
	private SharedPreferences PhotoUser;
	private Intent intentEvent = new Intent();
	private AlertDialog.Builder UidMsgNull;
	private TimerTask timeMsgNull;
	private AlertDialog.Builder DialogMsgChat;
	private SharedPreferences DadosUser;
	private AlertDialog.Builder DgBottomShet;
	private StorageReference StoreattUser = _firebase_storage.getReference("Atualização");
	private OnCompleteListener<Uri> _StoreattUser_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _StoreattUser_download_success_listener;
	private OnSuccessListener _StoreattUser_delete_success_listener;
	private OnProgressListener _StoreattUser_upload_progress_listener;
	private OnProgressListener _StoreattUser_download_progress_listener;
	private OnFailureListener _StoreattUser_failure_listener;
	
	private AlertDialog.Builder DgProgressAtt;
	private Intent i = new Intent();
	private AlertDialog.Builder TopUsers;
	private AlertDialog.Builder DgError;
	private DatabaseReference UserReceptWarning = _firebase.getReference("SetAviso");
	private ChildEventListener _UserReceptWarning_child_listener;
	private DatabaseReference PlayMusicHome = _firebase.getReference("MusicHome");
	private ChildEventListener _PlayMusicHome_child_listener;
	private MediaPlayer MusicHomeMediaPlayer;
	private DatabaseReference ReceptNotification = _firebase.getReference("Notification");
	private ChildEventListener _ReceptNotification_child_listener;
	private Notification Notifications;
	private Intent Service = new Intent();
	private RequestNetwork StoreNetwork;
	private RequestNetwork.RequestListener _StoreNetwork_request_listener;
	private ProgressDialog progessDialogDonwloadPhoto;
	
	private OnCompleteListener StoreCloudMessage_onCompleteListener;
	private Notification NotificationMusic;
	private AlertDialog.Builder DgEvents;
	private DatabaseReference EventAplication = _firebase.getReference("Eventos");
	private ChildEventListener _EventAplication_child_listener;
	private AlertDialog.Builder DgConection;
	private DatabaseReference VotingStore = _firebase.getReference("vote");
	private ChildEventListener _VotingStore_child_listener;
	private AlertDialog.Builder DgVote;
	private SharedPreferences ShddVotingcompleted;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.layout_menu);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(LayoutMenuActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = findViewById(R.id._nav_view);
		
		linear_back = findViewById(R.id.linear_back);
		textview1 = findViewById(R.id.textview1);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		button1 = findViewById(R.id.button1);
		linear2 = findViewById(R.id.linear2);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		_drawer_vscroll1 = _nav_view.findViewById(R.id.vscroll1);
		_drawer_linear2 = _nav_view.findViewById(R.id.linear2);
		_drawer_textview2 = _nav_view.findViewById(R.id.textview2);
		_drawer_circleimageview1 = _nav_view.findViewById(R.id.circleimageview1);
		_drawer_textview_name_email = _nav_view.findViewById(R.id.textview_name_email);
		_drawer_linear3 = _nav_view.findViewById(R.id.linear3);
		_drawer_linear5 = _nav_view.findViewById(R.id.linear5);
		_drawer_linear7 = _nav_view.findViewById(R.id.linear7);
		_drawer_linear11 = _nav_view.findViewById(R.id.linear11);
		_drawer_linear12 = _nav_view.findViewById(R.id.linear12);
		_drawer_linear9 = _nav_view.findViewById(R.id.linear9);
		_drawer_linear13 = _nav_view.findViewById(R.id.linear13);
		_drawer_linear10 = _nav_view.findViewById(R.id.linear10);
		_drawer_linear14 = _nav_view.findViewById(R.id.linear14);
		_drawer_linear15 = _nav_view.findViewById(R.id.linear15);
		_drawer_linear16 = _nav_view.findViewById(R.id.linear16);
		_drawer_linear17 = _nav_view.findViewById(R.id.linear17);
		_drawer_linear18 = _nav_view.findViewById(R.id.linear18);
		_drawer_linear_stand = _nav_view.findViewById(R.id.linear_stand);
		_drawer_imageview1 = _nav_view.findViewById(R.id.imageview1);
		_drawer_textview3 = _nav_view.findViewById(R.id.textview3);
		_drawer_imageview2 = _nav_view.findViewById(R.id.imageview2);
		_drawer_linear_upload = _nav_view.findViewById(R.id.linear_upload);
		_drawer_imageview3 = _nav_view.findViewById(R.id.imageview3);
		_drawer_textview4 = _nav_view.findViewById(R.id.textview4);
		_drawer_imageview4 = _nav_view.findViewById(R.id.imageview4);
		_drawer_linear_suport = _nav_view.findViewById(R.id.linear_suport);
		_drawer_imageview5 = _nav_view.findViewById(R.id.imageview5);
		_drawer_textview5 = _nav_view.findViewById(R.id.textview5);
		_drawer_imageview6 = _nav_view.findViewById(R.id.imageview6);
		_drawer_linear_metodos = _nav_view.findViewById(R.id.linear_metodos);
		_drawer_imageview11 = _nav_view.findViewById(R.id.imageview11);
		_drawer_textview8 = _nav_view.findViewById(R.id.textview8);
		_drawer_imageview12 = _nav_view.findViewById(R.id.imageview12);
		_drawer_linear_globalchat = _nav_view.findViewById(R.id.linear_globalchat);
		_drawer_imageview13 = _nav_view.findViewById(R.id.imageview13);
		_drawer_textview9 = _nav_view.findViewById(R.id.textview9);
		_drawer_imageview14 = _nav_view.findViewById(R.id.imageview14);
		_drawer_linear_viewModsStands = _nav_view.findViewById(R.id.linear_viewModsStands);
		_drawer_imageview7 = _nav_view.findViewById(R.id.imageview7);
		_drawer_textview6 = _nav_view.findViewById(R.id.textview6);
		_drawer_imageview8 = _nav_view.findViewById(R.id.imageview8);
		_drawer_linear_msgss = _nav_view.findViewById(R.id.linear_msgss);
		_drawer_imageview15 = _nav_view.findViewById(R.id.imageview15);
		_drawer_textview10 = _nav_view.findViewById(R.id.textview10);
		_drawer_imageview16 = _nav_view.findViewById(R.id.imageview16);
		_drawer_linear_Confi = _nav_view.findViewById(R.id.linear_Confi);
		_drawer_imageview9 = _nav_view.findViewById(R.id.imageview9);
		_drawer_textview7 = _nav_view.findViewById(R.id.textview7);
		_drawer_imageview10 = _nav_view.findViewById(R.id.imageview10);
		_drawer_linear_Parceiros = _nav_view.findViewById(R.id.linear_Parceiros);
		_drawer_imageview17 = _nav_view.findViewById(R.id.imageview17);
		_drawer_textview11 = _nav_view.findViewById(R.id.textview11);
		_drawer_imageview18 = _nav_view.findViewById(R.id.imageview18);
		_drawer_linear_News = _nav_view.findViewById(R.id.linear_News);
		_drawer_imageview19 = _nav_view.findViewById(R.id.imageview19);
		_drawer_textview12 = _nav_view.findViewById(R.id.textview12);
		_drawer_imageview20 = _nav_view.findViewById(R.id.imageview20);
		_drawer_linear_save = _nav_view.findViewById(R.id.linear_save);
		_drawer_imageview21 = _nav_view.findViewById(R.id.imageview21);
		_drawer_textview13 = _nav_view.findViewById(R.id.textview13);
		_drawer_imageview22 = _nav_view.findViewById(R.id.imageview22);
		_drawer_linear_ModsWhatsapp = _nav_view.findViewById(R.id.linear_ModsWhatsapp);
		_drawer_imageview23 = _nav_view.findViewById(R.id.imageview23);
		_drawer_textview14 = _nav_view.findViewById(R.id.textview14);
		_drawer_imageview24 = _nav_view.findViewById(R.id.imageview24);
		_drawer_linear_teams = _nav_view.findViewById(R.id.linear_teams);
		_drawer_imageview25 = _nav_view.findViewById(R.id.imageview25);
		_drawer_textview15 = _nav_view.findViewById(R.id.textview15);
		_drawer_imageview26 = _nav_view.findViewById(R.id.imageview26);
		user = FirebaseAuth.getInstance();
		DgAtt = new AlertDialog.Builder(this);
		DgAviso = new AlertDialog.Builder(this);
		DgAccount = new AlertDialog.Builder(this);
		Uid = getSharedPreferences("Uid", Activity.MODE_PRIVATE);
		ShdA = getSharedPreferences("AvTt", Activity.MODE_PRIVATE);
		Att = new AlertDialog.Builder(this);
		Aviso = new AlertDialog.Builder(this);
		Tems = getSharedPreferences("tema", Activity.MODE_PRIVATE);
		BanUserDg = new AlertDialog.Builder(this);
		PhotoUser = getSharedPreferences("PhotoUser", Activity.MODE_PRIVATE);
		UidMsgNull = new AlertDialog.Builder(this);
		DialogMsgChat = new AlertDialog.Builder(this);
		DadosUser = getSharedPreferences("ChatSp", Activity.MODE_PRIVATE);
		DgBottomShet = new AlertDialog.Builder(this);
		DgProgressAtt = new AlertDialog.Builder(this);
		TopUsers = new AlertDialog.Builder(this);
		DgError = new AlertDialog.Builder(this);
		StoreNetwork = new RequestNetwork(this);
		DgEvents = new AlertDialog.Builder(this);
		DgConection = new AlertDialog.Builder(this);
		DgVote = new AlertDialog.Builder(this);
		ShddVotingcompleted = getSharedPreferences("VotingCompleted", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (button1.getText().toString().equals("Parar de tocar a música")) {
					MusicHomeMediaPlayer.pause();
				}
				else {
					telas.setClass(getApplicationContext(), MetodosLayoutActivity.class);
					startActivity(telas);
				}
			}
		});
		
		textview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final com.google.android.material.bottomsheet.BottomSheetDialog TopUsers = new
				com.google.android.material.bottomsheet.BottomSheetDialog(LayoutMenuActivity.this);
				View lay = getLayoutInflater().inflate(R.layout.bottom_shet_top_users_layout, null); TopUsers.setContentView(lay);
				
				TextView txt = lay.findViewById(R.id.textview1);
				txt.setText(TopuserName);
				TopUsers.show();
			}
		});
		
		_StandView_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(PhotoUser.getString("UserPhotoDb", ""))) {
					Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("photo_lk").toString())).into(_drawer_circleimageview1);
					_drawer_textview_name_email.setText("Olá ".concat(_childValue.get("name_stand").toString()));
					Photo_Link_Donwload = _childValue.get("photo_lk").toString();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(PhotoUser.getString("UserPhotoDb", ""))) {
					Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("photo_lk").toString())).into(_drawer_circleimageview1);
					_drawer_textview_name_email.setText("Olá ".concat(_childValue.get("name_stand").toString()));
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		StandView.addChildEventListener(_StandView_child_listener);
		
		_FbAtu_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				nameapp = _childValue.get("nameapp").toString();
				if (ShdA.getString(_childKey, "").equals("true")) {
					
				}
				else {
					Att.setTitle(_childValue.get("Tt").toString());
					Att.setMessage(_childValue.get("Dd").toString());
					Att.setPositiveButton("Baixar ", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							ShdA.edit().putString(_childKey, "true").commit();
							_firebase_storage.getReferenceFromUrl(_childValue.get("lkatt").toString()).getFile(new File(FileUtil.getExternalStorageDir().concat("/StoreMedia/Atualização.apk"))).addOnSuccessListener(_StoreattUser_download_success_listener).addOnFailureListener(_StoreattUser_failure_listener).addOnProgressListener(_StoreattUser_download_progress_listener);
						}
					});
					Att.setCancelable(false);
					Att.create().show();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (ShdA.getString(_childKey, "").equals("true")) {
					
				}
				else {
					Att.setTitle(_childValue.get("Tt").toString());
					Att.setMessage(_childValue.get("Dd").toString());
					Att.setPositiveButton("Baixar ", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							ShdA.edit().putString(_childKey, "true").commit();
							_firebase_storage.getReferenceFromUrl(_childValue.get("lkatt").toString()).getFile(new File(FileUtil.getExternalStorageDir().concat("/StoreMedia/Atualização.apk"))).addOnSuccessListener(_StoreattUser_download_success_listener).addOnFailureListener(_StoreattUser_failure_listener).addOnProgressListener(_StoreattUser_download_progress_listener);
						}
					});
					Att.setCancelable(false);
					Att.create().show();
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		FbAtu.addChildEventListener(_FbAtu_child_listener);
		
		_FbAv_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Aviso.setTitle(_childValue.get("AT").toString());
				Aviso.setMessage(_childValue.get("AD").toString());
				Aviso.create().show();
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Aviso.setTitle(_childValue.get("AT").toString());
				Aviso.setMessage(_childValue.get("AD").toString());
				Aviso.create().show();
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		FbAv.addChildEventListener(_FbAv_child_listener);
		
		_TopU_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				TopuserName = _childValue.get("TopN").toString();
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				TopuserName = _childValue.get("TopN").toString();
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		TopU.addChildEventListener(_TopU_child_listener);
		
		_FbBanUser_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					BanUserDg.setTitle(_childValue.get("banT").toString());
					BanUserDg.setMessage(_childValue.get("banM").toString());
					BanUserDg.setCancelable(false);
					BanUserDg.create().show();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					BanUserDg.setTitle(_childValue.get("banT").toString());
					BanUserDg.setMessage(_childValue.get("banM").toString());
					BanUserDg.setCancelable(false);
					BanUserDg.create().show();
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		FbBanUser.addChildEventListener(_FbBanUser_child_listener);
		
		_StoreattUser_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_StoreattUser_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				SketchwareUtil.showMessage(getApplicationContext(), "Baixando ".concat(String.valueOf((long)(_progressValue)).concat("%")));
			}
		};
		
		_StoreattUser_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_StoreattUser_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				DgProgressAtt.setTitle("Instalado!");
				DgProgressAtt.setMessage("Abra seu Gerenciador de arquivos, Vá na pasta StoreMedia e instale a nova versão, Não perca as novidades da nova atualização.");
				DgProgressAtt.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				DgProgressAtt.create().show();
			}
		};
		
		_StoreattUser_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_StoreattUser_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_UserReceptWarning_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				textview2.setText(_childValue.get("MsgWarning").toString());
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				textview2.setText(_childValue.get("MsgWarning").toString());
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		UserReceptWarning.addChildEventListener(_UserReceptWarning_child_listener);
		
		_PlayMusicHome_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
						{final Activity activity = LayoutMenuActivity.this;
							final Context context = activity.getApplicationContext();
							final int notificationId = 8;
							final String channelId = "08";
							final String channelName = "NotificationMusic";
							
							new androidx.core.app.NotificationCompat.Builder(context, channelId){
									
									
									NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
									Intent intent335 = new Intent();
															   public void create(){
							
																	   intent335.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP); 
																	   PendingIntent pendingIntent = PendingIntent.getActivity(activity, 0, intent335, 0);
																	   
																	   if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
																			   NotificationChannel mChannel = new NotificationChannel(
																				   channelId, channelName, NotificationManager.IMPORTANCE_HIGH);
																			   notificationManager.createNotificationChannel(mChannel);
																		   }
																
							
							setSmallIcon(R.drawable.ic_audiotrack_black);
							setContentTitle("Evento com musica!");
							setContentText("Aproveite.");
							
							notificationManager.notify(notificationId, this.build());
							
																   }
						
														   }.create();}
						
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
				MusicHomeMediaPlayer.setLooping(true);
				MusicHomeMediaPlayer.start();
				button1.setText("Parar de tocar a música");
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		PlayMusicHome.addChildEventListener(_PlayMusicHome_child_listener);
		
		_ReceptNotification_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				_Notifications_random(_childValue.get("ContentTitle").toString(), _childValue.get("ContentText").toString());
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		ReceptNotification.addChildEventListener(_ReceptNotification_child_listener);
		
		_StoreNetwork_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_EventAplication_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				_EventVideo(_childValue, "Text", "LinkVideo");
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				_EventVideo(_childValue, "Text", "LinkVideo");
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		EventAplication.addChildEventListener(_EventAplication_child_listener);
		
		_VotingStore_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				childKey = _childKey;
				if (ShddVotingcompleted.getString(_childKey, "").equals("completed")) {
					ShddVotingcompleted.edit().remove("isOn").commit();
				}
				else {
					final AlertDialog DgVote = new AlertDialog.Builder(LayoutMenuActivity.this).create();
					View view =
					getLayoutInflater().inflate(R.layout.voting_screen, null);
					DgVote.setView(view);
					final Button ButtonGreen = view.findViewById(R.id.button_vote1);
					final Button ButtonRed = view.findViewById(R.id.button_vote2);
					TextView TextVoteTitle = view.findViewById(R.id.textview_titleVote);
					getClickGreen = 0;
					getClickRed = 0;
					TextVoteTitle.setText(_childValue.get("VoteText").toString());
					DgVote.setView(view);
					ButtonGreen.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							getClickGreen++;
							ShddVotingcompleted.edit().putString(_childKey, "completed").commit();
							ShddVotingcompleted.edit().putString("isOn", "green").commit();
						}
					});
					ButtonRed.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							getClickRed++;
							ShddVotingcompleted.edit().putString(_childKey, "completed").commit();
							ShddVotingcompleted.edit().putString("isOn", "red").commit();
						}
					});
					DgVote.show();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		VotingStore.addChildEventListener(_VotingStore_child_listener);
		
		user_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		user_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_user_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_user_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_user_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		KeyStorage = "TxGen1828FlLiLLii";
		_drawer_circleimageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Essa foto será definida,de acordo com sua foto de Perfil.");
			}
		});
		_drawer_linear_stand.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				telas.setClass(getApplicationContext(), DiceProfileActivity.class);
				startActivity(telas);
			}
		});
		_drawer_linear_upload.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				DgAccount.setTitle("Como quer fazer seu Upload?");
				DgAccount.setMessage("Se for enviar por link\nExemplo: Um link de Mediafire use a opção 1.\nSe for enviar o arquivo bruto \nExemplo: Enviar um arquivo da sua memória use a opção 2, Importante o app nao aceita arquivos do cartão SD. ");
				DgAccount.setPositiveButton("Opção 1", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						telas.setClass(getApplicationContext(), UploadLayoutActivity.class);
						startActivity(telas);
					}
				});
				DgAccount.setNeutralButton("Opção 2", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						telas.setClass(getApplicationContext(), UploadLayoutFileActivity.class);
						startActivity(telas);
					}
				});
				DgAccount.create().show();
			}
		});
		_drawer_linear_suport.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				telas.setClass(getApplicationContext(), SuporteLayoutActivity.class);
				startActivity(telas);
			}
		});
		_drawer_linear_viewModsStands.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (DadosUser.getString("ChatUser", "").equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Faça loggin no chat Global antes!");
				}
				else {
					telas.setClass(getApplicationContext(), StandViewLayoutActivity.class);
					startActivity(telas);
				}
			}
		});
		_drawer_linear_metodos.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				telas.setClass(getApplicationContext(), MetodosLayoutActivity.class);
				startActivity(telas);
			}
		});
		_drawer_linear_globalchat.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				telas.setClass(getApplicationContext(), LoginChatActivity.class);
				startActivity(telas);
			}
		});
		_drawer_linear_Confi.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				telas.setClass(getApplicationContext(), ConfigLayoutActivity.class);
				startActivity(telas);
			}
		});
		_drawer_linear_msgss.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Indisponível! Sistema com instabilidade,Aguarde futuras atualizações.");
			}
		});
		_drawer_linear_Parceiros.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				telas.setClass(getApplicationContext(), PartnersLayoutActivity.class);
				startActivity(telas);
			}
		});
		_drawer_linear_News.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				telas.setClass(getApplicationContext(), NewsLayoutActivity.class);
				startActivity(telas);
			}
		});
		_drawer_linear_save.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final com.google.android.material.bottomsheet.BottomSheetDialog DgBottomShet = new
				com.google.android.material.bottomsheet.BottomSheetDialog(LayoutMenuActivity.this);
				View lay = getLayoutInflater().inflate(R.layout.bottomshet_dialog_custom, null); DgBottomShet.setContentView(lay);
				
				final EditText Key = lay.findViewById(R.id.edittext1);
				final Button check = lay.findViewById(R.id.button1);
				DgBottomShet.show();
				check.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (Key.getText().toString().equals(KeyStorage)) {
							telas.setClass(getApplicationContext(), SaveFilesLayoutActivity.class);
							startActivity(telas);
						}
						else {
							Key.setError("Chave Incorreta!");
						}
					}
				});
			}
		});
		_drawer_linear_teams.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (DadosUser.getString("ChatUser", "").equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Faça loggin no chat Global antes!");
				}
				else {
					telas.setClass(getApplicationContext(), TeamsLayoutActivity.class);
					startActivity(telas);
				}
			}
		});
		_drawer_linear_ModsWhatsapp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Sistema não terminado! Implementação em breve.");
			}
		});
		_checkingUid();
	}
	
	@Override
	public void onBackPressed() {
		number++;
		if (number == 2) {
			finishAffinity();
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "clique novamente");
			time = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							number--;
						}
					});
				}
			};
			_timer.schedule(time, (int)(1500));
		}
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(0, 0, 0, "Privacy");
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		final int _id = item.getItemId();
		final String _title = (String) item.getTitle();
		if (_id == 0) {
			SketchwareUtil.showMessage(getApplicationContext(), "Em breve");
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	public void onStart() {
		super.onStart();
		_Aplication_without_network();
		_drawer.openDrawer(GravityCompat.START);
		_drawer.closeDrawer(GravityCompat.START);
	}
	public void _OnCreateDesing() {
		linear_back.setBackgroundDrawable(getResources().getDrawable(R.drawable.background_store_layout));
		textview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xB1FFFFFF));
		linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xB1FFFFFF));
		textview3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xB1FFFFFF));
		linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFF000000, Color.TRANSPARENT));
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)18, (int)4, 0xFF000000, 0xFFE0E0E0));
	}
	
	
	public void _DesingDrawer() {
		_drawer_linear_upload.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)5, 0xFF000000, 0xB1FFFFFF));
		_drawer_linear_ModsWhatsapp.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)5, 0xFF000000, 0xB1FFFFFF));
		_drawer_linear_stand.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)5, 0xFF000000, 0xB1FFFFFF));
		_drawer_linear_suport.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)5, 0xFF000000, 0xB1FFFFFF));
		_drawer_linear_metodos.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)5, 0xFF000000, 0xB1FFFFFF));
		_drawer_linear_globalchat.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)5, 0xFF000000, 0xB1FFFFFF));
		_drawer_linear_viewModsStands.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)5, 0xFF000000, 0xB1FFFFFF));
		_drawer_linear_msgss.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)5, 0xFF000000, 0xB1FFFFFF));
		_drawer_linear_Confi.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)5, 0xFF000000, 0xB1FFFFFF));
		_drawer_linear_Parceiros.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)5, 0xFF000000, 0xB1FFFFFF));
		_drawer_linear_News.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)5, 0xFF000000, 0xB1FFFFFF));
		_drawer_linear_save.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)5, 0xFF000000, 0xB1FFFFFF));
		_drawer_textview2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xB1FFFFFF));
		_drawer_linear_teams.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)5, 0xFF000000, 0xB1FFFFFF));
	}
	
	
	public void _AnimationTextEvent(final TextView _view, final String _Text) {
		_view.setText(_Text);
		_view.setSingleLine(true);
		_view.setEllipsize(TextUtils.TruncateAt.MARQUEE);
		_view.setSelected(true);
		
	}
	
	
	public void _Notifications_random(final String _Title, final String _Text) {
				{final Activity activity = LayoutMenuActivity.this;
					final Context context = activity.getApplicationContext();
					final int notificationId = 02;
					final String channelId = "2";
					final String channelName = "Notifications";
					
					new androidx.core.app.NotificationCompat.Builder(context, channelId){
							
							
							NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
							Intent intent335 = new Intent();
													   public void create(){
					
															   intent335.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP); 
															   PendingIntent pendingIntent = PendingIntent.getActivity(activity, 0, intent335, 0);
															   
															   if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
																	   NotificationChannel mChannel = new NotificationChannel(
																		   channelId, channelName, NotificationManager.IMPORTANCE_HIGH);
																	   notificationManager.createNotificationChannel(mChannel);
																   }
														
					
					setSmallIcon(R.drawable.ic_new_releases_black);
					setContentTitle(_Title);
					setContentText(_Text);
															   setAutoCancel(true);
					notificationManager.notify(notificationId, this.build());
					
														   }
				
												   }.create();}
				
	}
	
	
	public void _Aplication_without_network() {
		if (SketchwareUtil.isConnected(getApplicationContext())) {
			
		}
		else {
			DgConection.setTitle("Sem conexão com internet!");
			DgConection.setIcon(R.drawable.ic_signal_wifi_statusbar_connected_no_internet_black);
			DgConection.setMessage("Conecte-se com uma rede Wi-fi para usar o aplicativo.");
			DgConection.setPositiveButton("ok", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					finishAffinity();
				}
			});
		}
	}
	
	
	public void _checkingUid() {
		if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals("null")) {
			FirebaseAuth.getInstance().signOut();
			telas.setClass(getApplicationContext(), MainActivity.class);
			startActivity(telas);
			finish();
		}
		else {
			
		}
	}
	
	
	public void _EventVideo(final HashMap<String, Object> _getMap, final String _TextMap, final String _Path) {
		final com.google.android.material.bottomsheet.BottomSheetDialog DgEvents = new
		com.google.android.material.bottomsheet.BottomSheetDialog(LayoutMenuActivity.this);
		View lay = getLayoutInflater().inflate(R.layout.event_screen_video, null); DgEvents.setContentView(lay);
		final VideoView Video = lay.findViewById(R.id.videoview1);
		final TextView Text = lay.findViewById(R.id.textview1);
		Video.setVideoURI(Uri.parse(_getMap.get(_Path).toString()));
		Video.requestFocus();
		Text.setText(_getMap.get(_TextMap).toString());
		Video.start();
		DgEvents.show();
	}
	
	
	public void _VotingSystem() {
		if (ShddVotingcompleted.getString(childKey, "").equals("completed")) {
			
		}
		else {
			if (ShddVotingcompleted.getString("isOn", "").equals("red")) {
				VotingMap = new HashMap<>();
				VotingMap.put("VoteNumberRed", String.valueOf((long)(getClickRed)));
				VotingStore.child("Voting").updateChildren(VotingMap);
				SketchwareUtil.showMessage(getApplicationContext(), "Voto Contado, obrigado pela participação!");
			}
			else {
				if (ShddVotingcompleted.getString("isOn", "").equals("green")) {
					VotingMap = new HashMap<>();
					VotingMap.put("VoteNumberGreen", String.valueOf((long)(getClickGreen)));
					VotingStore.child("Voting").updateChildren(VotingMap);
					SketchwareUtil.showMessage(getApplicationContext(), "Voto Contado, obrigado pela participação!");
				}
			}
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}