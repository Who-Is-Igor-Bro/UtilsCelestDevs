package com.LojaMods.TexasCorp;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.File;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class LayoutTeamsChatActivity extends AppCompatActivity {
	
	public final int REQ_CD_PROFILETEAMEDIT = 101;
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private String Teamc1 = "";
	private String Teamc2 = "";
	private HashMap<String, Object> mapChatTeam = new HashMap<>();
	private String name = "";
	private String IdAdmin = "";
	private HashMap<String, Object> MapBanUserAcessTeam = new HashMap<>();
	private HashMap<String, Object> AcessDdsTeamModific = new HashMap<>();
	private String NameModificTeam = "";
	private String PathTeamProfile = "";
	private HashMap<String, Object> UsersAut = new HashMap<>();
	private String uids = "";
	
	private ArrayList<HashMap<String, Object>> ListTeamMsgs = new ArrayList<>();
	private ArrayList<String> StrTeamsModifc = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear_baseTeam;
	private ListView listview1;
	private LinearLayout linear_baseMsg;
	private CircleImageView circleimageview1;
	private TextView textview_nameTeam;
	private EditText edittext1;
	private LinearLayout linear_contadorCaracterChat;
	private ImageView imageview1;
	private TextView textview1;
	
	private DatabaseReference TeamC1 = _firebase.getReference("TeamC1");
	private ChildEventListener _TeamC1_child_listener;
	private DatabaseReference TeamC2 = _firebase.getReference("TeamC2");
	private ChildEventListener _TeamC2_child_listener;
	private DatabaseReference DdsTeam = _firebase.getReference("Teams");
	private ChildEventListener _DdsTeam_child_listener;
	private FirebaseAuth user;
	private OnCompleteListener<AuthResult> _user_create_user_listener;
	private OnCompleteListener<AuthResult> _user_sign_in_listener;
	private OnCompleteListener<Void> _user_reset_password_listener;
	private OnCompleteListener<Void> user_updateEmailListener;
	private OnCompleteListener<Void> user_updatePasswordListener;
	private OnCompleteListener<Void> user_emailVerificationSentListener;
	private OnCompleteListener<Void> user_deleteUserListener;
	private OnCompleteListener<Void> user_updateProfileListener;
	private OnCompleteListener<AuthResult> user_phoneAuthListener;
	private OnCompleteListener<AuthResult> user_googleSignInListener;
	
	private Intent intent = new Intent();
	private SharedPreferences ChatSp;
	private AlertDialog.Builder DgAdminTeamSettings;
	private Intent ProfileTeamEdit = new Intent(Intent.ACTION_GET_CONTENT);
	private DatabaseReference BanUserTeams = _firebase.getReference("BanUserTeamAcess");
	private ChildEventListener _BanUserTeams_child_listener;
	private StorageReference DadosTeam = _firebase_storage.getReference("TeamStorage");
	private OnCompleteListener<Uri> _DadosTeam_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _DadosTeam_download_success_listener;
	private OnSuccessListener _DadosTeam_delete_success_listener;
	private OnProgressListener _DadosTeam_upload_progress_listener;
	private OnProgressListener _DadosTeam_download_progress_listener;
	private OnFailureListener _DadosTeam_failure_listener;
	
	private Intent intentTeams = new Intent();
	private DatabaseReference AcessRequestTeam = _firebase.getReference("AcessRequest");
	private ChildEventListener _AcessRequestTeam_child_listener;
	private DatabaseReference UserTeamAut = _firebase.getReference("UsersTeamsAut");
	private ChildEventListener _UserTeamAut_child_listener;
	private AlertDialog.Builder DialogUserRequestAcess;
	private SharedPreferences UserAlreadyVerified;
	private Intent intentConfTeam = new Intent();
	private DatabaseReference MaxCaracter = _firebase.getReference("Caracter");
	private ChildEventListener _MaxCaracter_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.layout_teams_chat);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear_baseTeam = findViewById(R.id.linear_baseTeam);
		listview1 = findViewById(R.id.listview1);
		linear_baseMsg = findViewById(R.id.linear_baseMsg);
		circleimageview1 = findViewById(R.id.circleimageview1);
		textview_nameTeam = findViewById(R.id.textview_nameTeam);
		edittext1 = findViewById(R.id.edittext1);
		linear_contadorCaracterChat = findViewById(R.id.linear_contadorCaracterChat);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		user = FirebaseAuth.getInstance();
		ChatSp = getSharedPreferences("ChatSp", Activity.MODE_PRIVATE);
		DgAdminTeamSettings = new AlertDialog.Builder(this);
		ProfileTeamEdit.setType("image/*");
		ProfileTeamEdit.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		DialogUserRequestAcess = new AlertDialog.Builder(this);
		UserAlreadyVerified = getSharedPreferences("AlreadyVerified", Activity.MODE_PRIVATE);
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				
				return true;
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mapChatTeam = new HashMap<>();
				mapChatTeam.put("MsgTeam", edittext1.getText().toString());
				mapChatTeam.put("UidUserSend", FirebaseAuth.getInstance().getCurrentUser().getUid());
				mapChatTeam.put("nameUser", name);
				TeamC2.push().updateChildren(mapChatTeam);
				TeamC1.push().updateChildren(mapChatTeam);
				edittext1.setText("");
			}
		});
		
		_TeamC1_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				TeamC1.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						ListTeamMsgs = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								ListTeamMsgs.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listview1.setAdapter(new Listview1Adapter(ListTeamMsgs));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		TeamC1.addChildEventListener(_TeamC1_child_listener);
		
		_TeamC2_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		TeamC2.addChildEventListener(_TeamC2_child_listener);
		
		_DdsTeam_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (getIntent().getStringExtra("team").equals(_childKey)) {
					uids = _childValue.get("idCreator").toString();
					Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("TeamProfileLk").toString())).into(circleimageview1);
					textview_nameTeam.setText(_childValue.get("TeamName").toString());
					linear_baseTeam.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(_childValue.get("idCreator").toString())) {
								intentConfTeam.setClass(getApplicationContext(), TeamConfiLayoutActivity.class);
								startActivity(intentConfTeam);
							}
							else {
								
							}
						}
					});
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		DdsTeam.addChildEventListener(_DdsTeam_child_listener);
		
		_BanUserTeams_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		BanUserTeams.addChildEventListener(_BanUserTeams_child_listener);
		
		_DadosTeam_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_DadosTeam_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_DadosTeam_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_DadosTeam_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_DadosTeam_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_DadosTeam_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_AcessRequestTeam_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(uids)) {
					DialogUserRequestAcess.setTitle("Pedido de acesso a Team!");
					DialogUserRequestAcess.setMessage("Usuário ".concat(_childValue.get("UserAcessName").toString()).concat(" Deseja entrar na Team!"));
					DialogUserRequestAcess.setPositiveButton("Autorizar", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							UsersAut = new HashMap<>();
							UsersAut.put("Autorizados", _childValue.get("userAcessRequest").toString());
							UserTeamAut.child(_childValue.get("userAcessRequest").toString()).updateChildren(UsersAut);
							AcessRequestTeam.child(_childValue.get("userAcessRequest").toString()).removeValue();
							SketchwareUtil.showMessage(getApplicationContext(), "Usuário autorizado!");
						}
					});
					DialogUserRequestAcess.setNegativeButton("Negar", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							AcessRequestTeam.child(_childValue.get("userAcessRequest").toString()).removeValue();
						}
					});
					DialogUserRequestAcess.create().show();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		AcessRequestTeam.addChildEventListener(_AcessRequestTeam_child_listener);
		
		_UserTeamAut_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		UserTeamAut.addChildEventListener(_UserTeamAut_child_listener);
		
		_MaxCaracter_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		MaxCaracter.addChildEventListener(_MaxCaracter_child_listener);
		
		user_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		user_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_user_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_user_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_user_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		listview1.setStackFromBottom(true);
		listview1.setDivider(null);
		listview1.setDividerHeight(0);
		name = ChatSp.getString("ChatUser", "");
		TeamC1.removeEventListener(_TeamC1_child_listener);
		TeamC2.removeEventListener(_TeamC2_child_listener);
		Teamc1 = "Teamc1/".concat(getIntent().getStringExtra("team").concat("/".concat("Grupos")));
		Teamc2 = "Teamc1/".concat("Grupos".concat("/".concat(getIntent().getStringExtra("team"))));
		TeamC1=_firebase.getReference(Teamc1);
		TeamC2=_firebase.getReference(Teamc2);
		TeamC1.addChildEventListener(_TeamC1_child_listener);
		TeamC2.addChildEventListener(_TeamC2_child_listener);
		linear_contadorCaracterChat.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_PROFILETEAMEDIT:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				PathTeamProfile = _filePath.get((int)(0));
				NameModificTeam = Uri.parse(Uri.parse(_filePath.get((int)(0))).getLastPathSegment()).getLastPathSegment();
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	public void _DesingChatTeams() {
		linear_baseMsg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)22, (int)2, 0xFFFFFFFF, 0xB1000000));
		linear_baseTeam.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)8, 0xFF9E9E9E));
	}
	
	
	public void _OnClicks() {
		
	}
	
	
	public void _getLinkText(final TextView _textview) {
		_textview.setClickable(true);
		android.text.util.Linkify.addLinks(_textview, android.text.util.Linkify.ALL);
		_textview.setLinksClickable(true);
		_textview.setLinkTextColor(Color.parseColor("#FF7043"));
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.chat_teams_layout, null);
			}
			
			final LinearLayout linear_SeparateMsg = _view.findViewById(R.id.linear_SeparateMsg);
			final LinearLayout linear_separateMy = _view.findViewById(R.id.linear_separateMy);
			final LinearLayout linear_acessRequest = _view.findViewById(R.id.linear_acessRequest);
			final TextView textview_nameUser = _view.findViewById(R.id.textview_nameUser);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final TextView textview_Msg_Your = _view.findViewById(R.id.textview_Msg_Your);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView textview_msgMy = _view.findViewById(R.id.textview_msgMy);
			final TextView textview4 = _view.findViewById(R.id.textview4);
			final TextView textview_Informations = _view.findViewById(R.id.textview_Informations);
			final LinearLayout linear7 = _view.findViewById(R.id.linear7);
			final TextView textview_A = _view.findViewById(R.id.textview_A);
			
			linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xB1FFFFFF));
			linear_SeparateMsg.setBackgroundColor(Color.TRANSPARENT);
			linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xB1FFFFFF));
			linear_acessRequest.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xB1FFFFFF));
			if (ListTeamMsgs.get((int)_position).get("UidUserSend").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
				linear_SeparateMsg.setVisibility(View.GONE);
				linear_acessRequest.setVisibility(View.GONE);
				linear_separateMy.setVisibility(View.VISIBLE);
				textview_msgMy.setText(ListTeamMsgs.get((int)_position).get("MsgTeam").toString());
				_getLinkText(textview_msgMy);
			}
			else {
				linear_separateMy.setVisibility(View.GONE);
				linear_acessRequest.setVisibility(View.GONE);
				linear_SeparateMsg.setVisibility(View.VISIBLE);
				textview_nameUser.setText(ListTeamMsgs.get((int)_position).get("nameUser").toString());
				textview_Msg_Your.setText(ListTeamMsgs.get((int)_position).get("MsgTeam").toString());
				_getLinkText(textview_Msg_Your);
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}