package com.LojaMods.TexasCorp;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class PerfilStandActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private double followers = 0;
	private double buttonclick = 0;
	private HashMap<String, Object> MapSeguidores = new HashMap<>();
	private String id_user = "";
	private HashMap<String, Object> MapUserPrivacy = new HashMap<>();
	private String VerificUserTag = "";
	private HashMap<String, Object> MapPrivVerific = new HashMap<>();
	private String PrivString = "";
	
	private ArrayList<Double> Flow = new ArrayList<>();
	private ArrayList<String> FlowSeguidores = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> MapPrivUser = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear_editPerfil;
	private CircleImageView circleimageview1;
	private TextView textview_verifc;
	private TextView textview_name;
	private TextView textview_id;
	private TextView textview_descri;
	private LinearLayout linear_msg;
	private ImageView imageview_clickChat;
	
	private DatabaseReference ViewStand = _firebase.getReference("Stand");
	private ChildEventListener _ViewStand_child_listener;
	private Intent tela = new Intent();
	private FirebaseAuth user;
	private OnCompleteListener<AuthResult> _user_create_user_listener;
	private OnCompleteListener<AuthResult> _user_sign_in_listener;
	private OnCompleteListener<Void> _user_reset_password_listener;
	private OnCompleteListener<Void> user_updateEmailListener;
	private OnCompleteListener<Void> user_updatePasswordListener;
	private OnCompleteListener<Void> user_emailVerificationSentListener;
	private OnCompleteListener<Void> user_deleteUserListener;
	private OnCompleteListener<Void> user_updateProfileListener;
	private OnCompleteListener<AuthResult> user_phoneAuthListener;
	private OnCompleteListener<AuthResult> user_googleSignInListener;
	
	private Intent tl = new Intent();
	private SharedPreferences DadosUser;
	private SharedPreferences Sshd;
	private SharedPreferences ClickFolo;
	private Intent time = new Intent();
	private DatabaseReference FbLikss = _firebase.getReference("Likes");
	private ChildEventListener _FbLikss_child_listener;
	private Intent priIntent = new Intent();
	private AlertDialog.Builder DgSettingsProfile;
	private DatabaseReference FbUserPrivacy = _firebase.getReference("Privacy");
	private ChildEventListener _FbUserPrivacy_child_listener;
	private SharedPreferences PrivSw;
	private SharedPreferences AccountPermission;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.perfil_stand);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear_editPerfil = findViewById(R.id.linear_editPerfil);
		circleimageview1 = findViewById(R.id.circleimageview1);
		textview_verifc = findViewById(R.id.textview_verifc);
		textview_name = findViewById(R.id.textview_name);
		textview_id = findViewById(R.id.textview_id);
		textview_descri = findViewById(R.id.textview_descri);
		linear_msg = findViewById(R.id.linear_msg);
		imageview_clickChat = findViewById(R.id.imageview_clickChat);
		user = FirebaseAuth.getInstance();
		DadosUser = getSharedPreferences("uidD", Activity.MODE_PRIVATE);
		Sshd = getSharedPreferences("Veri", Activity.MODE_PRIVATE);
		ClickFolo = getSharedPreferences("Followes", Activity.MODE_PRIVATE);
		DgSettingsProfile = new AlertDialog.Builder(this);
		PrivSw = getSharedPreferences("PrivSw", Activity.MODE_PRIVATE);
		AccountPermission = getSharedPreferences("Permision", Activity.MODE_PRIVATE);
		
		linear_editPerfil.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final com.google.android.material.bottomsheet.BottomSheetDialog DgSettingsProfile = new
				com.google.android.material.bottomsheet.BottomSheetDialog(PerfilStandActivity.this);
				View lay = getLayoutInflater().inflate(R.layout.settings_profile_layout, null); DgSettingsProfile.setContentView(lay);
				
				final Button BtnC = lay.findViewById(R.id.button1);
				final Switch Sw = lay.findViewById(R.id.switch1);
				final Button Edit = lay.findViewById(R.id.button3);
				Edit.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFF000000, 0xFFBDBDBD));
				BtnC.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFF000000, 0xFFBDBDBD));
				final LinearLayout SwLinear = lay.findViewById(R.id.linear3);
				SwLinear.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, 0xB1FFFFFF));
				final LinearLayout EditLi = lay.findViewById(R.id.linear4);
				EditLi.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)18, (int)2, 0xFF000000, 0xB1FFFFFF));
				DgSettingsProfile.show();
				if (PrivSw.getString("Sw", "").equals("True")) {
					Sw.setChecked(true);
				}
				else {
					if (PrivSw.getString("Sw", "").equals("False")) {
						Sw.setChecked(false);
					}
				}
				BtnC.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (Sw.isChecked()) {
							Sw.setChecked(true);
							PrivSw.edit().putString("Sw", "True").commit();
							MapUserPrivacy = new HashMap<>();
							MapUserPrivacy.put("Priv", "true");
							FbUserPrivacy.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(MapUserPrivacy);
						}
						else {
							Sw.setChecked(false);
							PrivSw.edit().putString("Sw", "False").commit();
							MapUserPrivacy = new HashMap<>();
							MapUserPrivacy.put("Priv", "false");
							FbUserPrivacy.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(MapUserPrivacy);
						}
						DgSettingsProfile.dismiss();
					}
				});
				Edit.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						tl.setClass(getApplicationContext(), EditarPerfilLayoutActivity.class);
						DadosUser.edit().putString("uidEdit", getIntent().getStringExtra("uid")).commit();
						Sshd.edit().putString("Ver", textview_verifc.getText().toString()).commit();
						startActivity(tl);
						DgSettingsProfile.dismiss();
					}
				});
			}
		});
		
		textview_id.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		linear_msg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Sobre sistema!\nFuncionando todavia não vamos liberá-lo ainda.");
			}
		});
		
		imageview_clickChat.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Sobre sistema!\nFuncionando todavia não vamos liberá-lo ainda.");
			}
		});
		
		_ViewStand_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("uid"))) {
					Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("photo_lk").toString())).into(circleimageview1);
					textview_name.setText(_childValue.get("name_stand").toString());
					textview_descri.setText(_childValue.get("descri_stand").toString());
					textview_id.setText("Tag: ".concat(getIntent().getStringExtra("uid")));
					textview_verifc.setText(_childValue.get("verifc").toString());
					setTitle("Conta de ".concat(_childValue.get("name_stand").toString()));
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		ViewStand.addChildEventListener(_ViewStand_child_listener);
		
		_FbLikss_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		FbLikss.addChildEventListener(_FbLikss_child_listener);
		
		_FbUserPrivacy_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		FbUserPrivacy.addChildEventListener(_FbUserPrivacy_child_listener);
		
		user_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		user_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		user_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_user_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_user_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_user_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(getIntent().getStringExtra("uid"))) {
			linear_editPerfil.setVisibility(View.VISIBLE);
		}
		else {
			linear_editPerfil.setVisibility(View.INVISIBLE);
		}
		textview_id.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", getIntent().getStringExtra("uid")));
				SketchwareUtil.showMessage(getApplicationContext(), "Tag copiada!");
			}
		});
		if (textview_verifc.getText().toString().equals("")) {
			textview_verifc.setVisibility(View.GONE);
		}
	}
	
	public void _PerfilDesing() {
		linear1.setBackgroundDrawable(getResources().getDrawable(R.drawable.background_layout));
		linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xB1000000));
		linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)18, (int)2, 0xFF000000, 0xB1FFFFFF));
		linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)4, 0xFF000000, Color.TRANSPARENT));
		linear_msg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xB1FFFFFF));
		linear_editPerfil.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xB1FFFFFF));
		textview_verifc.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xB1000000));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}