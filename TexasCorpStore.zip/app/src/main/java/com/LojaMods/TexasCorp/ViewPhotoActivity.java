package com.LojaMods.TexasCorp;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.io.*;
import java.io.File;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class ViewPhotoActivity extends AppCompatActivity {
	
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ImageView imageview1;
	private ImageView imageview2;
	private LinearLayout linear3;
	private ImageView imageview3;
	
	private StorageReference PhotoDonwloadchat = _firebase_storage.getReference("DonwloadPhotoChat");
	private OnCompleteListener<Uri> _PhotoDonwloadchat_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _PhotoDonwloadchat_download_success_listener;
	private OnSuccessListener _PhotoDonwloadchat_delete_success_listener;
	private OnProgressListener _PhotoDonwloadchat_upload_progress_listener;
	private OnProgressListener _PhotoDonwloadchat_download_progress_listener;
	private OnFailureListener _PhotoDonwloadchat_failure_listener;
	
	private Notification Notification_Donwload_Photos;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.view_photo);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		imageview1 = findViewById(R.id.imageview1);
		imageview2 = findViewById(R.id.imageview2);
		linear3 = findViewById(R.id.linear3);
		imageview3 = findViewById(R.id.imageview3);
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_firebase_storage.getReferenceFromUrl(getIntent().getStringExtra("DonwloadPhoto")).getFile(new File(FileUtil.getExternalStorageDir().concat("/StoreMods/Media/").concat(getIntent().getStringExtra("PhotoName")))).addOnSuccessListener(_PhotoDonwloadchat_download_success_listener).addOnFailureListener(_PhotoDonwloadchat_failure_listener).addOnProgressListener(_PhotoDonwloadchat_download_progress_listener);
			}
		});
		
		_PhotoDonwloadchat_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_PhotoDonwloadchat_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				_Notification_donwload("Baixando Foto", "Progresso de download %".concat(String.valueOf((long)(_progressValue))));
			}
		};
		
		_PhotoDonwloadchat_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_PhotoDonwloadchat_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				_Notification_donwload("Foto baixada!", "Verifique no seus arquivos.");
			}
		};
		
		_PhotoDonwloadchat_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_PhotoDonwloadchat_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
	}
	
	private void initializeLogic() {
		Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("DonwloadPhoto"))).into(imageview1);
	}
	
	public void _Notification_donwload(final String _Titulo, final String _context) {
				{final Activity activity = ViewPhotoActivity.this;
					final Context context = activity.getApplicationContext();
					final int notificationId = 03;
					final String channelId = "3";
					final String channelName = "Notification_Donwload_Photos";
					
					new androidx.core.app.NotificationCompat.Builder(context, channelId){
							
							
							NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
							Intent intent335 = new Intent();
													   public void create(){
					
															   intent335.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP); 
															   PendingIntent pendingIntent = PendingIntent.getActivity(activity, 0, intent335, 0);
															   
															   if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
																	   NotificationChannel mChannel = new NotificationChannel(
																		   channelId, channelName, NotificationManager.IMPORTANCE_HIGH);
																	   notificationManager.createNotificationChannel(mChannel);
																   }
														
					
					setSmallIcon(R.drawable.ic_folder_open_black);
					setContentTitle(_Titulo);
					setContentText(_context);
															   setAutoCancel(true);
					notificationManager.notify(notificationId, this.build());
					
														   }
				
												   }.create();}
				
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}