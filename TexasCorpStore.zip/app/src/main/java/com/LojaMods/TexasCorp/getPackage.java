package Store.System.Utils;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;

public class getPackage extends Activity {

private String versionApp = "";
private SharedPreferences PackageShdd;
     
      @Override
     protected void onCreate(Bundle savedInstanceState) {
              super.onCreate(savedInstanceState);
              
              PackageShdd.edit().putString("PackageInfo", versionApp).commit();
       }
	   
	public void PackageVersion(){
	
	try {
	android.content.pm.PackageInfo versionAppP = this.getPackageManager().getPackageInfo(getPackageName(), 0);
	versionApp = versionAppP.versionName;
} catch (android.content.pm.PackageManager.NameNotFoundException e) {
	e.printStackTrace();
}
	
	}
     
}